﻿Imports MySql.Data.MySqlClient

Public Class mainForm
    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click
        Application.Exit()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim dash As New dashboard()
        dash.Show()



    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs)
        Close()
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        Dim check = DialogResult = MessageBox.Show("Are you want to logout?", "Confirmation message", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If check = DialogResult.Yes Then
            Dim log As New LoginForm()
            LoginForm.Show()

            Me.Hide()

        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim add As New addUser()
        addUser.Show()
        Me.Hide()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim ad As addclassForm()
        addclassForm.Show()
        Me.Hide()


    End Sub

    Private Sub Panel8_Paint(sender As Object, e As PaintEventArgs) Handles Panel8.Paint

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Dim connectionString = "server=localhost;user id=root;password=;database=ur_huye_system"
        Using conn As New MySqlConnection(connectionString)
            conn.Open()


            ' Load Total Bookings
            Dim Query = "SELECT SUM(user_id) FROM users"
            Dim cmd As New MySqlCommand(Query, conn)
            Button6.Text = "Total users: " & cmd.ExecuteScalar.ToString

        End Using
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Dim connectionString = "server=localhost;user id=root;password=;database=ur_huye_system"
        Using conn As New MySqlConnection(connectionString)
            conn.Open()


            ' Load Total Bookings
            Dim Query = "SELECT SUM(classroom_id) FROM classrooms"
            Dim cmd As New MySqlCommand(Query, conn)
            Button7.Text = "Total classrooms: " & cmd.ExecuteScalar.ToString

        End Using
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Dim connectionString = "server=localhost;user id=root;password=;database=ur_huye_system"
        Using conn As New MySqlConnection(connectionString)
            conn.Open()


            ' Load Total Bookings
            Dim Query = "SELECT SUM(notification_id) FROM notifications"
            Dim cmd As New MySqlCommand(Query, conn)
            Button8.Text = "Total Tickets raised: " & cmd.ExecuteScalar.ToString

        End Using
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim ad As addticketsForm()
        addticketsForm.Show()
        Me.Hide()
    End Sub


    Private Sub LoadDashboardData()
        Dim connectionString As String = "server=localhost;user id=root;password=;database=ur_huye_system"
        Using conn As New MySqlConnection(connectionString)
            Try
                conn.Open()

                ' Create a DataTable to store the dashboard data
                Dim dashboardTable As New DataTable()
                dashboardTable.Columns.Add("Month", GetType(String))
                dashboardTable.Columns.Add("TotalBookings", GetType(Integer))
                dashboardTable.Columns.Add("AvailableRooms", GetType(Integer))
                dashboardTable.Columns.Add("BookedRooms", GetType(Integer))
                dashboardTable.Columns.Add("ActiveUsers", GetType(Integer))

                ' Query for monthly statistics
                Dim query As String = "
                SELECT 
                    DATE_FORMAT(b.date_booked, '%Y-%m') as Month,
                    COUNT(DISTINCT b.booking_id) as TotalBookings,
                    (SELECT COUNT(*) FROM classrooms WHERE status = 'free') as AvailableRooms,
                    (SELECT COUNT(*) FROM classrooms WHERE status = 'booked') as BookedRooms,
                    COUNT(DISTINCT b.user_id) as ActiveUsers
                FROM bookings b
                GROUP BY DATE_FORMAT(b.date_booked, '%Y-%m')
                ORDER BY Month DESC
                LIMIT 12"

                Using cmd As New MySqlCommand(query, conn)
                    Using reader As MySqlDataReader = cmd.ExecuteReader()
                        While reader.Read()
                            Dim row = dashboardTable.NewRow()
                            row("Month") = DateTime.ParseExact(reader("Month").ToString(), "yyyy-MM", Nothing).ToString("MMM yyyy")
                            row("TotalBookings") = Convert.ToInt32(reader("TotalBookings"))
                            row("AvailableRooms") = Convert.ToInt32(reader("AvailableRooms"))
                            row("BookedRooms") = Convert.ToInt32(reader("BookedRooms"))
                            row("ActiveUsers") = Convert.ToInt32(reader("ActiveUsers"))
                            dashboardTable.Rows.Add(row)
                        End While
                    End Using
                End Using

                ' Bind data to DataGridView
                dgvDashboard.DataSource = dashboardTable

                ' Format DataGridView
                FormatDashboardGrid()

            Catch ex As Exception
                MessageBox.Show("Error loading dashboard data: " & ex.Message)
            End Try
        End Using
    End Sub

    Private Sub FormatDashboardGrid()
        With dgvDashboard
            ' Set column headers
            .Columns("Month").HeaderText = "Month"
            .Columns("TotalBookings").HeaderText = "Total Bookings"
            .Columns("AvailableRooms").HeaderText = "Available Rooms"
            .Columns("BookedRooms").HeaderText = "Booked Rooms"
            .Columns("ActiveUsers").HeaderText = "Active Users"

            ' Set column styles
            For Each col As DataGridViewColumn In .Columns
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                col.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
                col.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill
            Next

            ' Set alternating row colors
            .AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray
            .EnableHeadersVisualStyles = False
            .ColumnHeadersDefaultCellStyle.BackColor = Color.DarkGray
            .ColumnHeadersDefaultCellStyle.ForeColor = Color.White
            .ColumnHeadersHeight = 40

            ' Other formatting
            .ReadOnly = True
            .AllowUserToAddRows = False
            .AllowUserToDeleteRows = False
            .AllowUserToOrderColumns = True
            .SelectionMode = DataGridViewSelectionMode.FullRowSelect
        End With
    End Sub
    Private Sub AdminDashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadDashboardData()
    End Sub

    Private Sub Button5_Click_1(sender As Object, e As EventArgs) Handles Button5.Click
        Dim st As New bookingstatus()
        bookingstatus.Show()
        Me.Hide()
    End Sub
End Class