﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class addBooking
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(addBooking))
        Panel1 = New Panel()
        Label4 = New Label()
        Label3 = New Label()
        Panel2 = New Panel()
        Label2 = New Label()
        Label1 = New Label()
        PictureBox1 = New PictureBox()
        Panel3 = New Panel()
        Button4 = New Button()
        Button1 = New Button()
        Button5 = New Button()
        Button3 = New Button()
        Button2 = New Button()
        Label5 = New Label()
        PictureBox2 = New PictureBox()
        Panel4 = New Panel()
        Panel6 = New Panel()
        Button6 = New Button()
        btnBook = New Button()
        DateTimePicker1 = New DateTimePicker()
        TextBox2 = New TextBox()
        TextBox1 = New TextBox()
        Label9 = New Label()
        Label8 = New Label()
        Label7 = New Label()
        Panel5 = New Panel()
        class_DataGridView = New DataGridView()
        Label6 = New Label()
        Panel1.SuspendLayout()
        Panel2.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        Panel3.SuspendLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        Panel4.SuspendLayout()
        Panel6.SuspendLayout()
        Panel5.SuspendLayout()
        CType(class_DataGridView, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.SteelBlue
        Panel1.Controls.Add(Label4)
        Panel1.Controls.Add(Label3)
        Panel1.Dock = DockStyle.Top
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(1200, 43)
        Panel1.TabIndex = 4
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label4.ForeColor = Color.Red
        Label4.Location = New Point(1146, 9)
        Label4.Name = "Label4"
        Label4.Size = New Size(29, 29)
        Label4.TabIndex = 1
        Label4.Text = "X"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Courier New", 10F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label3.ForeColor = Color.White
        Label3.Location = New Point(12, 9)
        Label3.Name = "Label3"
        Label3.Size = New Size(514, 22)
        Label3.TabIndex = 0
        Label3.Text = "UR Huye Campus Online Class Booking System"
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.White
        Panel2.Controls.Add(Label2)
        Panel2.Controls.Add(Label1)
        Panel2.Controls.Add(PictureBox1)
        Panel2.Dock = DockStyle.Left
        Panel2.Location = New Point(0, 43)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(274, 657)
        Panel2.TabIndex = 5
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.ForeColor = Color.DarkSlateGray
        Label2.Location = New Point(38, 375)
        Label2.Name = "Label2"
        Label2.Size = New Size(176, 29)
        Label2.TabIndex = 0
        Label2.Text = "Huye Campus"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Microsoft Sans Serif", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = Color.SteelBlue
        Label1.Location = New Point(12, 72)
        Label1.Name = "Label1"
        Label1.Size = New Size(252, 22)
        Label1.TabIndex = 0
        Label1.Text = "UNIVERSITY OF RWANDA"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(0, 121)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(271, 234)
        PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox1.TabIndex = 0
        PictureBox1.TabStop = False
        ' 
        ' Panel3
        ' 
        Panel3.BackColor = Color.DarkSlateGray
        Panel3.BorderStyle = BorderStyle.FixedSingle
        Panel3.Controls.Add(Button4)
        Panel3.Controls.Add(Button1)
        Panel3.Controls.Add(Button5)
        Panel3.Controls.Add(Button3)
        Panel3.Controls.Add(Button2)
        Panel3.Controls.Add(Label5)
        Panel3.Controls.Add(PictureBox2)
        Panel3.Dock = DockStyle.Right
        Panel3.ForeColor = Color.White
        Panel3.Location = New Point(942, 43)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(258, 657)
        Panel3.TabIndex = 6
        ' 
        ' Button4
        ' 
        Button4.FlatStyle = FlatStyle.Flat
        Button4.Font = New Font("Tahoma", 11F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button4.ForeColor = Color.MediumTurquoise
        Button4.Image = CType(resources.GetObject("Button4.Image"), Image)
        Button4.ImageAlign = ContentAlignment.MiddleLeft
        Button4.Location = New Point(19, 421)
        Button4.Name = "Button4"
        Button4.Size = New Size(213, 51)
        Button4.TabIndex = 8
        Button4.Text = "Raise Tickets"
        Button4.UseVisualStyleBackColor = True
        ' 
        ' Button1
        ' 
        Button1.FlatStyle = FlatStyle.Flat
        Button1.Font = New Font("Tahoma", 11F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button1.ForeColor = Color.MediumTurquoise
        Button1.Image = CType(resources.GetObject("Button1.Image"), Image)
        Button1.ImageAlign = ContentAlignment.MiddleLeft
        Button1.Location = New Point(19, 283)
        Button1.Name = "Button1"
        Button1.Size = New Size(213, 51)
        Button1.TabIndex = 7
        Button1.Text = "Dashboard"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Button5
        ' 
        Button5.FlatStyle = FlatStyle.Flat
        Button5.Font = New Font("Tahoma", 10F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button5.ForeColor = Color.MintCream
        Button5.Image = CType(resources.GetObject("Button5.Image"), Image)
        Button5.ImageAlign = ContentAlignment.MiddleRight
        Button5.Location = New Point(15, 601)
        Button5.Name = "Button5"
        Button5.Size = New Size(213, 51)
        Button5.TabIndex = 6
        Button5.Text = "logout"
        Button5.UseVisualStyleBackColor = True
        ' 
        ' Button3
        ' 
        Button3.FlatStyle = FlatStyle.Flat
        Button3.Font = New Font("Tahoma", 11F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button3.ForeColor = Color.MediumTurquoise
        Button3.Image = CType(resources.GetObject("Button3.Image"), Image)
        Button3.ImageAlign = ContentAlignment.MiddleLeft
        Button3.Location = New Point(19, 489)
        Button3.Name = "Button3"
        Button3.Size = New Size(213, 51)
        Button3.TabIndex = 5
        Button3.Text = "Settings"
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.FlatStyle = FlatStyle.Flat
        Button2.Font = New Font("Tahoma", 11F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button2.ForeColor = Color.MediumTurquoise
        Button2.Image = CType(resources.GetObject("Button2.Image"), Image)
        Button2.ImageAlign = ContentAlignment.MiddleLeft
        Button2.Location = New Point(19, 352)
        Button2.Name = "Button2"
        Button2.Size = New Size(213, 51)
        Button2.TabIndex = 3
        Button2.Text = "Booking Class"
        Button2.TextAlign = ContentAlignment.MiddleRight
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Baskerville Old Face", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label5.Location = New Point(45, 240)
        Label5.Name = "Label5"
        Label5.Size = New Size(159, 27)
        Label5.TabIndex = 1
        Label5.Text = "Welcome, CP"
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), Image)
        PictureBox2.Location = New Point(6, 72)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(240, 135)
        PictureBox2.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox2.TabIndex = 0
        PictureBox2.TabStop = False
        ' 
        ' Panel4
        ' 
        Panel4.BackColor = Color.White
        Panel4.BorderStyle = BorderStyle.FixedSingle
        Panel4.Controls.Add(Panel6)
        Panel4.Controls.Add(Panel5)
        Panel4.Controls.Add(Label6)
        Panel4.Dock = DockStyle.Fill
        Panel4.Location = New Point(274, 43)
        Panel4.Name = "Panel4"
        Panel4.Size = New Size(668, 657)
        Panel4.TabIndex = 7
        ' 
        ' Panel6
        ' 
        Panel6.BackColor = Color.DarkSlateGray
        Panel6.Controls.Add(Button6)
        Panel6.Controls.Add(btnBook)
        Panel6.Controls.Add(DateTimePicker1)
        Panel6.Controls.Add(TextBox2)
        Panel6.Controls.Add(TextBox1)
        Panel6.Controls.Add(Label9)
        Panel6.Controls.Add(Label8)
        Panel6.Controls.Add(Label7)
        Panel6.Location = New Point(2, 342)
        Panel6.Name = "Panel6"
        Panel6.Size = New Size(665, 310)
        Panel6.TabIndex = 2
        ' 
        ' Button6
        ' 
        Button6.FlatAppearance.BorderColor = Color.FromArgb(CByte(4), CByte(68), CByte(122))
        Button6.FlatAppearance.BorderSize = 3
        Button6.FlatAppearance.MouseDownBackColor = Color.Teal
        Button6.FlatAppearance.MouseOverBackColor = Color.Green
        Button6.FlatStyle = FlatStyle.Popup
        Button6.Font = New Font("SimSun", 11F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button6.ForeColor = SystemColors.ControlLightLight
        Button6.Location = New Point(421, 232)
        Button6.Name = "Button6"
        Button6.Size = New Size(120, 50)
        Button6.TabIndex = 7
        Button6.Text = "clear"
        Button6.UseVisualStyleBackColor = True
        ' 
        ' btnBook
        ' 
        btnBook.BackColor = Color.FromArgb(CByte(4), CByte(68), CByte(111))
        btnBook.FlatAppearance.BorderColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        btnBook.FlatAppearance.BorderSize = 3
        btnBook.FlatAppearance.MouseDownBackColor = Color.Maroon
        btnBook.FlatAppearance.MouseOverBackColor = Color.Maroon
        btnBook.FlatStyle = FlatStyle.Popup
        btnBook.Font = New Font("SimSun", 11F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnBook.ForeColor = SystemColors.ControlLightLight
        btnBook.Location = New Point(241, 232)
        btnBook.Name = "btnBook"
        btnBook.Size = New Size(120, 50)
        btnBook.TabIndex = 6
        btnBook.Text = "Booking"
        btnBook.UseVisualStyleBackColor = False
        ' 
        ' DateTimePicker1
        ' 
        DateTimePicker1.Location = New Point(241, 167)
        DateTimePicker1.Name = "DateTimePicker1"
        DateTimePicker1.Size = New Size(300, 31)
        DateTimePicker1.TabIndex = 5
        ' 
        ' TextBox2
        ' 
        TextBox2.Location = New Point(241, 99)
        TextBox2.Name = "TextBox2"
        TextBox2.Size = New Size(301, 31)
        TextBox2.TabIndex = 4
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(241, 33)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(301, 31)
        TextBox1.TabIndex = 3
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Location = New Point(25, 173)
        Label9.Name = "Label9"
        Label9.Size = New Size(115, 25)
        Label9.TabIndex = 2
        Label9.Text = "Date Booked"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Location = New Point(25, 105)
        Label8.Name = "Label8"
        Label8.Size = New Size(70, 25)
        Label8.TabIndex = 1
        Label8.Text = "user_ID"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Location = New Point(25, 36)
        Label7.Name = "Label7"
        Label7.Size = New Size(77, 25)
        Label7.TabIndex = 0
        Label7.Text = "Class_ID"
        ' 
        ' Panel5
        ' 
        Panel5.Controls.Add(class_DataGridView)
        Panel5.Location = New Point(5, 71)
        Panel5.Name = "Panel5"
        Panel5.Size = New Size(663, 231)
        Panel5.TabIndex = 1
        ' 
        ' class_DataGridView
        ' 
        class_DataGridView.BackgroundColor = SystemColors.ControlLightLight
        class_DataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        class_DataGridView.Dock = DockStyle.Fill
        class_DataGridView.Location = New Point(0, 0)
        class_DataGridView.Name = "class_DataGridView"
        class_DataGridView.RowHeadersWidth = 62
        class_DataGridView.Size = New Size(663, 231)
        class_DataGridView.TabIndex = 0
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Tahoma", 14F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label6.ForeColor = Color.SteelBlue
        Label6.Location = New Point(190, 14)
        Label6.Name = "Label6"
        Label6.Size = New Size(217, 34)
        Label6.TabIndex = 0
        Label6.Text = "Booking Class "
        ' 
        ' addBooking
        ' 
        AutoScaleDimensions = New SizeF(10F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1200, 700)
        Controls.Add(Panel4)
        Controls.Add(Panel3)
        Controls.Add(Panel2)
        Controls.Add(Panel1)
        FormBorderStyle = FormBorderStyle.None
        Name = "addBooking"
        Text = "addBooking"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        Panel3.ResumeLayout(False)
        Panel3.PerformLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        Panel4.ResumeLayout(False)
        Panel4.PerformLayout()
        Panel6.ResumeLayout(False)
        Panel6.PerformLayout()
        Panel5.ResumeLayout(False)
        CType(class_DataGridView, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Button5 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Label6 As Label
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Panel5 As Panel
    Friend WithEvents class_DataGridView As DataGridView
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents btnBook As Button
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Button6 As Button
End Class
