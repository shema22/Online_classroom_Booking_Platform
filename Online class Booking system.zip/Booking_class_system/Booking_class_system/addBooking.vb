﻿Imports MySql.Data.MySqlClient
Imports Org.BouncyCastle.Tls
Imports System.Windows.Forms

Public Class addBooking

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click
        Application.Exit()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim check = DialogResult = MessageBox.Show("Are you want to logout?", "Confirmation message", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If check = DialogResult.Yes Then
            LoginForm.Show()

            Me.Hide()

        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim dash As New userDashboard()
        userDashboard.Show()
        Me.Hide()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim b As New addBooking()
        Me.Show()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim t As New ticketsForm()
        ticketsForm.Show()
        Me.Hide()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        MessageBox.Show("This is property of UR! the system is under deploy so keep wait until mentained or contact IT Department.thank you!")
    End Sub

    Private Sub RetrieveData()
        Dim connectionString As String = "server=localhost;user id=root;password=;database=ur_huye_system"
        Using conn As New MySqlConnection(connectionString)
            Try
                conn.Open()
                Dim query As String = "SELECT classroom_id,name,size,location FROM classrooms WHERE status = 'free'"

                Using cmd As New MySqlCommand(query, conn)
                    Dim adapter As New MySqlDataAdapter(cmd)
                    Dim table As New DataTable()
                    adapter.Fill(table)
                    class_DataGridView.DataSource = table


                    If class_DataGridView.Columns.Contains("classroom_id") Then
                        class_DataGridView.Columns("classroom_id").HeaderText = "Class ID"
                    End If

                    If class_DataGridView.Columns.Contains("name") Then
                        class_DataGridView.Columns("name").HeaderText = "Class Name"
                    End If
                    If class_DataGridView.Columns.Contains("size") Then
                        class_DataGridView.Columns("size").HeaderText = "Class Size"
                    End If

                    If class_DataGridView.Columns.Contains("location") Then
                        class_DataGridView.Columns("location").HeaderText = "Location"
                    End If


                End Using
            Catch ex As MySqlException
                MessageBox.Show("Database error: " & ex.Message)
            Catch ex As Exception
                MessageBox.Show("An error occurred: " & ex.Message)
            End Try
        End Using
    End Sub

    Private Sub UserManagementForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        RetrieveData()
    End Sub
    Private Sub btnBook_Click(sender As Object, e As EventArgs) Handles btnBook.Click
        If class_DataGridView.SelectedRows.Count > 0 Then
            Dim selectedRow = class_DataGridView.SelectedRows(0)
            Dim classroomId = Convert.ToInt32(selectedRow.Cells("classroom_id").Value)
            Dim userId = Convert.ToInt32(TextBox2.Text)
            Dim dateBooked = Date.Now

            Dim connectionString = "server=localhost;user id=root;password=;database=ur_huye_system"
            Using conn As New MySqlConnection(connectionString)
                Try
                    conn.Open()
                    ' Insert booking data
                    Dim insertQuery = "INSERT INTO bookings (classroom_id, user_id, date_booked) VALUES (@classroom_id, @user_id, @date_booked)"
                    Using insertCmd As New MySqlCommand(insertQuery, conn)
                        insertCmd.Parameters.AddWithValue("@classroom_id", classroomId)
                        insertCmd.Parameters.AddWithValue("@user_id", userId)
                        insertCmd.Parameters.AddWithValue("@date_booked", dateBooked)
                        insertCmd.ExecuteNonQuery()
                    End Using

                    ' Update classroom status to 'booked'
                    Dim updateQuery = "UPDATE classrooms SET status = 'booked' WHERE classroom_id = @classroom_id"
                    Using updateCmd As New MySqlCommand(updateQuery, conn)
                        updateCmd.Parameters.AddWithValue("@classroom_id", classroomId)
                        updateCmd.ExecuteNonQuery()
                    End Using

                    MessageBox.Show("Classroom booked successfully!")

                    ' Set a timer to update the status back to 'free' after 12 hours
                    Dim timer As New Timers.Timer
                    timer.Interval = 12 * 60 * 60 * 1000 ' 12 hours in milliseconds
                    AddHandler timer.Elapsed, Sub(btnBook, ex)
                                                  TimerElapsed(sender, e, classroomId)
                                              End Sub
                    timer.Start()

                    RetrieveData() ' Refresh the DataGridView to display updated data
                Catch ex As MySqlException
                    MessageBox.Show("Database error: " & ex.Message)
                Catch ex As Exception
                    MessageBox.Show("An error occurred: " & ex.Message)
                End Try
            End Using
        Else
            MessageBox.Show("Please select a classroom to book.")
        End If
    End Sub
    Private Sub TimerElapsed(sender As Object, e As Timers.ElapsedEventArgs, classroomId As Integer)
        ' Stop and dispose of the timer
        CType(sender, Timers.Timer).Stop()
        CType(sender, Timers.Timer).Dispose()

        ' Update classroom status
        UpdateClassroomStatus(classroomId)
    End Sub
    Private Sub UpdateClassroomStatus(classroomId As Integer)
        Dim connectionString As String = "server=localhost;user id=root;password=;database=ur_huye_system"
        Using conn As New MySqlConnection(connectionString)
            Try
                conn.Open()
                Dim query As String = "UPDATE classrooms SET status = 'free' WHERE classroom_id = @classroom_id"
                Using cmd As New MySqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@classroom_id", classroomId)
                    cmd.ExecuteNonQuery()
                End Using
                MessageBox.Show("Classroom status updated to 'free'")
            Catch ex As MySqlException
                MessageBox.Show("Database error: " & ex.Message)
            Catch ex As Exception
                MessageBox.Show("An error occurred: " & ex.Message)
            End Try
        End Using
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        DateTimePicker1.Text = ""
    End Sub
End Class