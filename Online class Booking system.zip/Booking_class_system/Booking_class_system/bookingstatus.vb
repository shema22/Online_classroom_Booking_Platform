﻿Imports MySql.Data.MySqlClient

Public Class bookingstatus
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim das As New mainForm()
        mainForm.Show()
        Me.Hide()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim usr As New addUser()
        addUser.Show()
        Me.Hide()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim cl As New addclassForm()
        addclassForm.Show()
        Me.Hide()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim ann As New addticketsForm()
        addticketsForm.Show()
        Me.Hide()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim st As New bookingstatus()
        Me.Show()
    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click
        Application.Exit()
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        Dim lg As New LoginForm()
        LoginForm.Show()
        Me.Hide()
    End Sub

    Private Sub RetrieveData()
        Dim connectionString As String = "server=localhost;user id=root;password=;database=ur_huye_system"
        Using conn As New MySqlConnection(connectionString)
            Try
                conn.Open()
                Dim query As String = "SELECT classroom_id, name, size, location, details FROM classrooms WHERE status='free'"
                Using cmd As New MySqlCommand(query, conn)
                    Dim adapter As New MySqlDataAdapter(cmd)
                    Dim table As New DataTable()
                    adapter.Fill(table)
                    DataGridView1.DataSource = table


                    If DataGridView1.Columns.Contains("classroom_id") Then
                        DataGridView1.Columns("classroom_id").HeaderText = "Class ID"
                    End If
                    If DataGridView1.Columns.Contains("name") Then
                        DataGridView1.Columns("name").HeaderText = "Class Name"
                    End If
                    If DataGridView1.Columns.Contains("size") Then
                        DataGridView1.Columns("size").HeaderText = "Class Size"
                    End If

                    If DataGridView1.Columns.Contains("location") Then
                        DataGridView1.Columns("location").HeaderText = "Location"
                    End If
                    If DataGridView1.Columns.Contains("details") Then
                        DataGridView1.Columns("details").HeaderText = "Details"
                    End If
                End Using
            Catch ex As MySqlException
                MessageBox.Show("Database error: " & ex.Message)
            Catch ex As Exception
                MessageBox.Show("An error occurred: " & ex.Message)
            End Try
        End Using
    End Sub

    Private Sub UserManagementForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        RetrieveData()

    End Sub
    Private Sub LoadBookingData()
        Dim connectionString As String = "server=localhost;user id=root;password=;database=ur_huye_system"
        Using conn As New MySqlConnection(connectionString)
            Try
                conn.Open()

                ' Create the SQL query with INNER JOINs
                Dim query As String = "SELECT b.booking_id, c.name AS classroom_name, " &
                                    "c.size, c.location, u.names AS user_name, " &
                                    "b.date_booked " &
                                    "FROM bookings b " &
                                    "INNER JOIN classrooms c ON b.classroom_id = c.classroom_id " &
                                    "INNER JOIN users u ON b.user_id = u.user_id"

                ' Create adapter and dataset
                Dim adapter As New MySqlDataAdapter(query, conn)
                Dim dataset As New DataSet()

                ' Fill the dataset
                adapter.Fill(dataset, "BookingDetails")

                ' Bind the data to DataGridView
                DataGridView2.DataSource = dataset.Tables("BookingDetails")

                ' Optionally format the column headers for better readability
                DataGridView2.Columns("classroom_name").HeaderText = "Classroom Name"
                DataGridView2.Columns("size").HeaderText = "Size"
                DataGridView2.Columns("location").HeaderText = "Location"
                DataGridView2.Columns("user_name").HeaderText = "Booked By"
                DataGridView2.Columns("date_booked").HeaderText = "Booking Date"

                ' AutoSize the columns for better appearance
                DataGridView1.AutoResizeColumns()

            Catch ex As MySqlException
                MessageBox.Show("Error loading data: " & ex.Message)
            End Try
        End Using
    End Sub
    Private Sub YourForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadBookingData()
    End Sub
End Class