﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class mainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(mainForm))
        Panel1 = New Panel()
        Label3 = New Label()
        Label2 = New Label()
        Panel2 = New Panel()
        Button5 = New Button()
        Label4 = New Label()
        PictureBox2 = New PictureBox()
        Button3 = New Button()
        Button4 = New Button()
        Button2 = New Button()
        Button1 = New Button()
        Label1 = New Label()
        PictureBox1 = New PictureBox()
        Panel3 = New Panel()
        Panel4 = New Panel()
        dgvDashboard = New DataGridView()
        Panel5 = New Panel()
        Panel6 = New Panel()
        Button8 = New Button()
        Label6 = New Label()
        PictureBox3 = New PictureBox()
        Panel7 = New Panel()
        Button7 = New Button()
        Label8 = New Label()
        PictureBox4 = New PictureBox()
        Panel8 = New Panel()
        Button6 = New Button()
        Label10 = New Label()
        PictureBox5 = New PictureBox()
        Panel1.SuspendLayout()
        Panel2.SuspendLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        Panel3.SuspendLayout()
        Panel4.SuspendLayout()
        CType(dgvDashboard, ComponentModel.ISupportInitialize).BeginInit()
        Panel5.SuspendLayout()
        Panel6.SuspendLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        Panel7.SuspendLayout()
        CType(PictureBox4, ComponentModel.ISupportInitialize).BeginInit()
        Panel8.SuspendLayout()
        CType(PictureBox5, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = SystemColors.ControlLightLight
        Panel1.Controls.Add(Label3)
        Panel1.Controls.Add(Label2)
        Panel1.Dock = DockStyle.Top
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(1200, 38)
        Panel1.TabIndex = 0
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Cursor = Cursors.Hand
        Label3.Font = New Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.ForeColor = Color.FromArgb(CByte(192), CByte(0), CByte(0))
        Label3.Location = New Point(1166, 5)
        Label3.Name = "Label3"
        Label3.Size = New Size(31, 29)
        Label3.TabIndex = 1
        Label3.Text = "X"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("SimSun", 11F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.ForeColor = Color.SteelBlue
        Label2.Location = New Point(3, 12)
        Label2.Name = "Label2"
        Label2.Size = New Size(526, 22)
        Label2.TabIndex = 0
        Label2.Text = "UR Huye Campus Online Class Booking System "
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.SteelBlue
        Panel2.BorderStyle = BorderStyle.Fixed3D
        Panel2.Controls.Add(Button5)
        Panel2.Controls.Add(Label4)
        Panel2.Controls.Add(PictureBox2)
        Panel2.Controls.Add(Button3)
        Panel2.Controls.Add(Button4)
        Panel2.Controls.Add(Button2)
        Panel2.Controls.Add(Button1)
        Panel2.Controls.Add(Label1)
        Panel2.Controls.Add(PictureBox1)
        Panel2.Dock = DockStyle.Left
        Panel2.Location = New Point(0, 38)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(300, 662)
        Panel2.TabIndex = 1
        ' 
        ' Button5
        ' 
        Button5.Cursor = Cursors.Hand
        Button5.FlatAppearance.MouseDownBackColor = Color.FromArgb(CByte(192), CByte(0), CByte(0))
        Button5.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(192), CByte(0), CByte(0))
        Button5.FlatStyle = FlatStyle.Flat
        Button5.Font = New Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button5.ForeColor = SystemColors.ControlLightLight
        Button5.Image = CType(resources.GetObject("Button5.Image"), Image)
        Button5.ImageAlign = ContentAlignment.MiddleLeft
        Button5.Location = New Point(30, 500)
        Button5.Name = "Button5"
        Button5.Size = New Size(241, 50)
        Button5.TabIndex = 7
        Button5.Text = "Booking status"
        Button5.TextAlign = ContentAlignment.MiddleRight
        Button5.UseVisualStyleBackColor = True
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Tahoma", 9F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label4.ForeColor = SystemColors.ControlLightLight
        Label4.Location = New Point(58, 638)
        Label4.Name = "Label4"
        Label4.Size = New Size(65, 22)
        Label4.TabIndex = 6
        Label4.Text = "Logout"
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), Image)
        PictureBox2.Location = New Point(-2, 634)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(58, 26)
        PictureBox2.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox2.TabIndex = 1
        PictureBox2.TabStop = False
        ' 
        ' Button3
        ' 
        Button3.Cursor = Cursors.Hand
        Button3.FlatAppearance.MouseDownBackColor = Color.FromArgb(CByte(192), CByte(0), CByte(0))
        Button3.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(192), CByte(0), CByte(0))
        Button3.FlatStyle = FlatStyle.Flat
        Button3.Font = New Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button3.ForeColor = SystemColors.ControlLightLight
        Button3.Image = CType(resources.GetObject("Button3.Image"), Image)
        Button3.ImageAlign = ContentAlignment.MiddleLeft
        Button3.Location = New Point(30, 432)
        Button3.Name = "Button3"
        Button3.Size = New Size(241, 50)
        Button3.TabIndex = 5
        Button3.Text = "Announcement " & vbCrLf
        Button3.TextAlign = ContentAlignment.MiddleRight
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Button4
        ' 
        Button4.Cursor = Cursors.Hand
        Button4.FlatStyle = FlatStyle.Flat
        Button4.Font = New Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button4.ForeColor = SystemColors.ControlLightLight
        Button4.Image = CType(resources.GetObject("Button4.Image"), Image)
        Button4.ImageAlign = ContentAlignment.MiddleLeft
        Button4.Location = New Point(30, 376)
        Button4.Name = "Button4"
        Button4.Size = New Size(241, 50)
        Button4.TabIndex = 4
        Button4.Text = " Classroom"
        Button4.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Cursor = Cursors.Hand
        Button2.FlatAppearance.MouseDownBackColor = Color.DarkSeaGreen
        Button2.FlatAppearance.MouseOverBackColor = Color.DarkSeaGreen
        Button2.FlatStyle = FlatStyle.Flat
        Button2.Font = New Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button2.ForeColor = SystemColors.ControlLightLight
        Button2.Image = CType(resources.GetObject("Button2.Image"), Image)
        Button2.ImageAlign = ContentAlignment.MiddleLeft
        Button2.Location = New Point(30, 306)
        Button2.Name = "Button2"
        Button2.Size = New Size(241, 50)
        Button2.TabIndex = 3
        Button2.Text = " CPs / User"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button1
        ' 
        Button1.Cursor = Cursors.Hand
        Button1.FlatAppearance.BorderColor = Color.White
        Button1.FlatAppearance.MouseDownBackColor = Color.FromArgb(CByte(0), CByte(192), CByte(192))
        Button1.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(0), CByte(192), CByte(192))
        Button1.FlatStyle = FlatStyle.Flat
        Button1.Font = New Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button1.ForeColor = SystemColors.ControlLightLight
        Button1.Image = CType(resources.GetObject("Button1.Image"), Image)
        Button1.ImageAlign = ContentAlignment.MiddleLeft
        Button1.Location = New Point(25, 235)
        Button1.Name = "Button1"
        Button1.Size = New Size(241, 50)
        Button1.TabIndex = 2
        Button1.Text = "Dashboard"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Bahnschrift", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = SystemColors.ControlLightLight
        Label1.Location = New Point(58, 173)
        Label1.Name = "Label1"
        Label1.Size = New Size(191, 29)
        Label1.TabIndex = 2
        Label1.Text = "welcome, Admin"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(58, 29)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(186, 123)
        PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox1.TabIndex = 2
        PictureBox1.TabStop = False
        ' 
        ' Panel3
        ' 
        Panel3.BorderStyle = BorderStyle.FixedSingle
        Panel3.Controls.Add(Panel4)
        Panel3.Controls.Add(Panel5)
        Panel3.Dock = DockStyle.Fill
        Panel3.Location = New Point(300, 38)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(900, 662)
        Panel3.TabIndex = 2
        ' 
        ' Panel4
        ' 
        Panel4.BackColor = Color.DarkSlateGray
        Panel4.BorderStyle = BorderStyle.FixedSingle
        Panel4.Controls.Add(dgvDashboard)
        Panel4.Location = New Point(5, 270)
        Panel4.Name = "Panel4"
        Panel4.Size = New Size(884, 379)
        Panel4.TabIndex = 3
        ' 
        ' dgvDashboard
        ' 
        dgvDashboard.BackgroundColor = Color.Teal
        dgvDashboard.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvDashboard.Dock = DockStyle.Fill
        dgvDashboard.Location = New Point(0, 0)
        dgvDashboard.Name = "dgvDashboard"
        dgvDashboard.RowHeadersWidth = 62
        dgvDashboard.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgvDashboard.Size = New Size(882, 377)
        dgvDashboard.TabIndex = 0
        ' 
        ' Panel5
        ' 
        Panel5.BackColor = Color.White
        Panel5.BorderStyle = BorderStyle.FixedSingle
        Panel5.Controls.Add(Panel6)
        Panel5.Controls.Add(Panel7)
        Panel5.Controls.Add(Panel8)
        Panel5.Location = New Point(3, 5)
        Panel5.Name = "Panel5"
        Panel5.Size = New Size(884, 229)
        Panel5.TabIndex = 2
        ' 
        ' Panel6
        ' 
        Panel6.BackColor = Color.FromArgb(CByte(4), CByte(87), CByte(122))
        Panel6.BorderStyle = BorderStyle.FixedSingle
        Panel6.Controls.Add(Button8)
        Panel6.Controls.Add(Label6)
        Panel6.Controls.Add(PictureBox3)
        Panel6.Location = New Point(616, 26)
        Panel6.Name = "Panel6"
        Panel6.Size = New Size(248, 179)
        Panel6.TabIndex = 2
        ' 
        ' Button8
        ' 
        Button8.FlatStyle = FlatStyle.Flat
        Button8.ForeColor = SystemColors.ControlLightLight
        Button8.Location = New Point(3, 110)
        Button8.Name = "Button8"
        Button8.Size = New Size(240, 65)
        Button8.TabIndex = 4
        Button8.Text = "check"
        Button8.UseVisualStyleBackColor = True
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Tahoma", 9F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label6.ForeColor = Color.White
        Label6.Location = New Point(74, 25)
        Label6.Name = "Label6"
        Label6.Size = New Size(122, 22)
        Label6.TabIndex = 2
        Label6.Text = "Tickets Raised"
        ' 
        ' PictureBox3
        ' 
        PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), Image)
        PictureBox3.Location = New Point(3, 25)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(60, 60)
        PictureBox3.TabIndex = 3
        PictureBox3.TabStop = False
        ' 
        ' Panel7
        ' 
        Panel7.BackColor = Color.FromArgb(CByte(4), CByte(87), CByte(122))
        Panel7.BorderStyle = BorderStyle.FixedSingle
        Panel7.Controls.Add(Button7)
        Panel7.Controls.Add(Label8)
        Panel7.Controls.Add(PictureBox4)
        Panel7.Location = New Point(306, 26)
        Panel7.Name = "Panel7"
        Panel7.Size = New Size(248, 179)
        Panel7.TabIndex = 1
        ' 
        ' Button7
        ' 
        Button7.FlatStyle = FlatStyle.Flat
        Button7.ForeColor = SystemColors.ControlLightLight
        Button7.Location = New Point(3, 109)
        Button7.Name = "Button7"
        Button7.Size = New Size(240, 65)
        Button7.TabIndex = 4
        Button7.Text = "check"
        Button7.UseVisualStyleBackColor = True
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Tahoma", 9F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label8.ForeColor = Color.White
        Label8.Location = New Point(76, 25)
        Label8.Name = "Label8"
        Label8.Size = New Size(142, 22)
        Label8.TabIndex = 2
        Label8.Text = "Total classrooms"
        ' 
        ' PictureBox4
        ' 
        PictureBox4.Image = CType(resources.GetObject("PictureBox4.Image"), Image)
        PictureBox4.Location = New Point(3, 25)
        PictureBox4.Name = "PictureBox4"
        PictureBox4.Size = New Size(60, 60)
        PictureBox4.TabIndex = 3
        PictureBox4.TabStop = False
        ' 
        ' Panel8
        ' 
        Panel8.BackColor = Color.FromArgb(CByte(4), CByte(87), CByte(122))
        Panel8.BorderStyle = BorderStyle.FixedSingle
        Panel8.Controls.Add(Button6)
        Panel8.Controls.Add(Label10)
        Panel8.Controls.Add(PictureBox5)
        Panel8.Location = New Point(14, 24)
        Panel8.Name = "Panel8"
        Panel8.Size = New Size(252, 181)
        Panel8.TabIndex = 0
        ' 
        ' Button6
        ' 
        Button6.FlatStyle = FlatStyle.Flat
        Button6.ForeColor = SystemColors.ControlLightLight
        Button6.Location = New Point(3, 110)
        Button6.Name = "Button6"
        Button6.Size = New Size(240, 65)
        Button6.TabIndex = 1
        Button6.Text = "check"
        Button6.UseVisualStyleBackColor = True
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Font = New Font("Tahoma", 9F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label10.ForeColor = Color.White
        Label10.Location = New Point(74, 25)
        Label10.Name = "Label10"
        Label10.Size = New Size(169, 22)
        Label10.TabIndex = 0
        Label10.Text = "Registered User/Cps"
        ' 
        ' PictureBox5
        ' 
        PictureBox5.Image = CType(resources.GetObject("PictureBox5.Image"), Image)
        PictureBox5.Location = New Point(-1, 25)
        PictureBox5.Name = "PictureBox5"
        PictureBox5.Size = New Size(69, 60)
        PictureBox5.TabIndex = 0
        PictureBox5.TabStop = False
        ' 
        ' mainForm
        ' 
        AutoScaleDimensions = New SizeF(10F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImageLayout = ImageLayout.None
        ClientSize = New Size(1200, 700)
        Controls.Add(Panel3)
        Controls.Add(Panel2)
        Controls.Add(Panel1)
        FormBorderStyle = FormBorderStyle.None
        Name = "mainForm"
        StartPosition = FormStartPosition.CenterScreen
        Text = "mainForm"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        Panel3.ResumeLayout(False)
        Panel4.ResumeLayout(False)
        CType(dgvDashboard, ComponentModel.ISupportInitialize).EndInit()
        Panel5.ResumeLayout(False)
        Panel6.ResumeLayout(False)
        Panel6.PerformLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        Panel7.ResumeLayout(False)
        Panel7.PerformLayout()
        CType(PictureBox4, ComponentModel.ISupportInitialize).EndInit()
        Panel8.ResumeLayout(False)
        Panel8.PerformLayout()
        CType(PictureBox5, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Button1 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Button5 As Button
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Label6 As Label
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Label8 As Label
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents Panel8 As Panel
    Friend WithEvents Label10 As Label
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents Button6 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents dgvDashboard As DataGridView
End Class
