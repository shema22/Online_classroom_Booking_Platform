﻿Public Class Form1
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Timer1.Start()
        Panel2.Width += 6


        If (Panel2.Width >= 973) Then
            Timer1.Stop()

            LoginForm.Show()

            Hide()
        End If
    End Sub
End Class
