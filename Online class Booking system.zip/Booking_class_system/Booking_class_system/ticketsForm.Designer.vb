﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ticketsForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As DataGridViewCellStyle = New DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ticketsForm))
        Dim DataGridViewCellStyle2 As DataGridViewCellStyle = New DataGridViewCellStyle()
        Panel1 = New Panel()
        Label4 = New Label()
        Label3 = New Label()
        Panel2 = New Panel()
        pnlMain = New Panel()
        dgvUsers = New DataGridView()
        lblTitle = New Label()
        Label2 = New Label()
        Label6 = New Label()
        Label1 = New Label()
        PictureBox1 = New PictureBox()
        Panel3 = New Panel()
        Button5 = New Button()
        Button3 = New Button()
        Button4 = New Button()
        Button2 = New Button()
        Button1 = New Button()
        Label5 = New Label()
        PictureBox2 = New PictureBox()
        Panel4 = New Panel()
        Panel5 = New Panel()
        Button10 = New Button()
        Button12 = New Button()
        message = New TextBox()
        Label8 = New Label()
        user_id = New TextBox()
        Label9 = New Label()
        Button6 = New Button()
        Button7 = New Button()
        DataGridView1 = New DataGridView()
        Label7 = New Label()
        Panel1.SuspendLayout()
        Panel2.SuspendLayout()
        pnlMain.SuspendLayout()
        CType(dgvUsers, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        Panel3.SuspendLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        Panel4.SuspendLayout()
        Panel5.SuspendLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.FromArgb(CByte(4), CByte(68), CByte(112))
        Panel1.Controls.Add(Label4)
        Panel1.Controls.Add(Label3)
        Panel1.Dock = DockStyle.Top
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(1200, 43)
        Panel1.TabIndex = 4
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label4.ForeColor = Color.Red
        Label4.Location = New Point(1159, 9)
        Label4.Name = "Label4"
        Label4.Size = New Size(29, 29)
        Label4.TabIndex = 1
        Label4.Text = "X"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Courier New", 10F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label3.ForeColor = Color.White
        Label3.Location = New Point(12, 9)
        Label3.Name = "Label3"
        Label3.Size = New Size(514, 22)
        Label3.TabIndex = 0
        Label3.Text = "UR Huye Campus Online Class Booking System"
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.White
        Panel2.Controls.Add(pnlMain)
        Panel2.Controls.Add(Label2)
        Panel2.Controls.Add(Label6)
        Panel2.Controls.Add(Label1)
        Panel2.Controls.Add(PictureBox1)
        Panel2.Dock = DockStyle.Left
        Panel2.Location = New Point(0, 43)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(274, 657)
        Panel2.TabIndex = 5
        ' 
        ' pnlMain
        ' 
        pnlMain.BackColor = Color.White
        pnlMain.BorderStyle = BorderStyle.FixedSingle
        pnlMain.Controls.Add(dgvUsers)
        pnlMain.Controls.Add(lblTitle)
        pnlMain.Location = New Point(270, 72)
        pnlMain.Name = "pnlMain"
        pnlMain.Size = New Size(673, 290)
        pnlMain.TabIndex = 8
        ' 
        ' dgvUsers
        ' 
        dgvUsers.AllowUserToOrderColumns = True
        dgvUsers.BackgroundColor = Color.FromArgb(CByte(4), CByte(68), CByte(122))
        dgvUsers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvUsers.Location = New Point(15, 37)
        dgvUsers.MultiSelect = False
        dgvUsers.Name = "dgvUsers"
        DataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = Color.FromArgb(CByte(4), CByte(68), CByte(122))
        DataGridViewCellStyle1.Font = New Font("Segoe UI", 9F)
        DataGridViewCellStyle1.ForeColor = Color.White
        DataGridViewCellStyle1.SelectionBackColor = Color.CadetBlue
        DataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = DataGridViewTriState.True
        dgvUsers.RowHeadersDefaultCellStyle = DataGridViewCellStyle1
        dgvUsers.RowHeadersWidth = 62
        dgvUsers.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgvUsers.Size = New Size(850, 248)
        dgvUsers.StandardTab = True
        dgvUsers.TabIndex = 1
        dgvUsers.VirtualMode = True
        ' 
        ' lblTitle
        ' 
        lblTitle.AutoSize = True
        lblTitle.Font = New Font("Tahoma", 10F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        lblTitle.Location = New Point(3, 10)
        lblTitle.Name = "lblTitle"
        lblTitle.Size = New Size(152, 24)
        lblTitle.TabIndex = 0
        lblTitle.Text = "CPs/User's Data"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.ForeColor = Color.DarkSlateGray
        Label2.Location = New Point(38, 375)
        Label2.Name = "Label2"
        Label2.Size = New Size(176, 29)
        Label2.TabIndex = 0
        Label2.Text = "Huye Campus"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.FlatStyle = FlatStyle.Flat
        Label6.Font = New Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label6.ForeColor = Color.SteelBlue
        Label6.Location = New Point(38, 464)
        Label6.Name = "Label6"
        Label6.Size = New Size(210, 29)
        Label6.TabIndex = 6
        Label6.Text = "CP Tickets Panel"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Microsoft Sans Serif", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = Color.SteelBlue
        Label1.Location = New Point(12, 72)
        Label1.Name = "Label1"
        Label1.Size = New Size(252, 22)
        Label1.TabIndex = 0
        Label1.Text = "UNIVERSITY OF RWANDA"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(0, 121)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(274, 234)
        PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox1.TabIndex = 0
        PictureBox1.TabStop = False
        ' 
        ' Panel3
        ' 
        Panel3.BackColor = Color.FromArgb(CByte(4), CByte(68), CByte(122))
        Panel3.BorderStyle = BorderStyle.FixedSingle
        Panel3.Controls.Add(Button5)
        Panel3.Controls.Add(Button3)
        Panel3.Controls.Add(Button4)
        Panel3.Controls.Add(Button2)
        Panel3.Controls.Add(Button1)
        Panel3.Controls.Add(Label5)
        Panel3.Controls.Add(PictureBox2)
        Panel3.Dock = DockStyle.Right
        Panel3.ForeColor = Color.White
        Panel3.Location = New Point(942, 43)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(258, 657)
        Panel3.TabIndex = 7
        ' 
        ' Button5
        ' 
        Button5.BackColor = Color.FromArgb(CByte(0), CByte(192), CByte(192))
        Button5.FlatStyle = FlatStyle.Flat
        Button5.Font = New Font("Tahoma", 10F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button5.ForeColor = Color.MintCream
        Button5.Image = CType(resources.GetObject("Button5.Image"), Image)
        Button5.ImageAlign = ContentAlignment.MiddleLeft
        Button5.Location = New Point(15, 601)
        Button5.Name = "Button5"
        Button5.Size = New Size(213, 51)
        Button5.TabIndex = 6
        Button5.Text = "logout"
        Button5.UseVisualStyleBackColor = False
        ' 
        ' Button3
        ' 
        Button3.BackColor = Color.White
        Button3.FlatStyle = FlatStyle.Flat
        Button3.Font = New Font("Tahoma", 11F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button3.ForeColor = Color.MediumTurquoise
        Button3.Image = CType(resources.GetObject("Button3.Image"), Image)
        Button3.ImageAlign = ContentAlignment.MiddleLeft
        Button3.Location = New Point(15, 501)
        Button3.Name = "Button3"
        Button3.Size = New Size(213, 51)
        Button3.TabIndex = 5
        Button3.Text = "Settings"
        Button3.UseVisualStyleBackColor = False
        ' 
        ' Button4
        ' 
        Button4.BackColor = Color.White
        Button4.FlatStyle = FlatStyle.Flat
        Button4.Font = New Font("Tahoma", 11F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button4.ForeColor = Color.MediumTurquoise
        Button4.Image = CType(resources.GetObject("Button4.Image"), Image)
        Button4.ImageAlign = ContentAlignment.MiddleLeft
        Button4.Location = New Point(15, 441)
        Button4.Name = "Button4"
        Button4.Size = New Size(213, 51)
        Button4.TabIndex = 4
        Button4.Text = "Raise Tickets"
        Button4.UseVisualStyleBackColor = False
        ' 
        ' Button2
        ' 
        Button2.BackColor = Color.White
        Button2.FlatStyle = FlatStyle.Flat
        Button2.Font = New Font("Tahoma", 11F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button2.ForeColor = Color.MediumTurquoise
        Button2.Image = CType(resources.GetObject("Button2.Image"), Image)
        Button2.ImageAlign = ContentAlignment.MiddleLeft
        Button2.Location = New Point(15, 384)
        Button2.Name = "Button2"
        Button2.Size = New Size(213, 51)
        Button2.TabIndex = 3
        Button2.Text = "Booking Class"
        Button2.TextAlign = ContentAlignment.MiddleRight
        Button2.UseVisualStyleBackColor = False
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.White
        Button1.FlatStyle = FlatStyle.Flat
        Button1.Font = New Font("Tahoma", 11F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button1.ForeColor = Color.MediumTurquoise
        Button1.Image = CType(resources.GetObject("Button1.Image"), Image)
        Button1.ImageAlign = ContentAlignment.MiddleLeft
        Button1.Location = New Point(15, 314)
        Button1.Name = "Button1"
        Button1.Size = New Size(213, 51)
        Button1.TabIndex = 2
        Button1.Text = "Dashboard"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Baskerville Old Face", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label5.Location = New Point(45, 240)
        Label5.Name = "Label5"
        Label5.Size = New Size(159, 27)
        Label5.TabIndex = 1
        Label5.Text = "Welcome, CP"
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), Image)
        PictureBox2.Location = New Point(6, 72)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(240, 135)
        PictureBox2.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox2.TabIndex = 0
        PictureBox2.TabStop = False
        ' 
        ' Panel4
        ' 
        Panel4.BackColor = Color.White
        Panel4.BorderStyle = BorderStyle.FixedSingle
        Panel4.Controls.Add(Panel5)
        Panel4.Controls.Add(Button6)
        Panel4.Controls.Add(Button7)
        Panel4.Controls.Add(DataGridView1)
        Panel4.Controls.Add(Label7)
        Panel4.Dock = DockStyle.Fill
        Panel4.Location = New Point(274, 43)
        Panel4.Name = "Panel4"
        Panel4.Size = New Size(668, 657)
        Panel4.TabIndex = 8
        ' 
        ' Panel5
        ' 
        Panel5.BackColor = Color.White
        Panel5.BorderStyle = BorderStyle.FixedSingle
        Panel5.Controls.Add(Button10)
        Panel5.Controls.Add(Button12)
        Panel5.Controls.Add(message)
        Panel5.Controls.Add(Label8)
        Panel5.Controls.Add(user_id)
        Panel5.Controls.Add(Label9)
        Panel5.Dock = DockStyle.Bottom
        Panel5.Location = New Point(0, 373)
        Panel5.Name = "Panel5"
        Panel5.Size = New Size(666, 282)
        Panel5.TabIndex = 13
        ' 
        ' Button10
        ' 
        Button10.BackColor = Color.SteelBlue
        Button10.FlatAppearance.BorderSize = 0
        Button10.FlatAppearance.MouseDownBackColor = Color.Blue
        Button10.FlatAppearance.MouseOverBackColor = Color.Blue
        Button10.FlatStyle = FlatStyle.Flat
        Button10.Font = New Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button10.ForeColor = SystemColors.ControlLightLight
        Button10.Location = New Point(373, 226)
        Button10.Name = "Button10"
        Button10.Size = New Size(112, 34)
        Button10.TabIndex = 14
        Button10.Text = "clear"
        Button10.UseVisualStyleBackColor = False
        ' 
        ' Button12
        ' 
        Button12.BackColor = Color.SteelBlue
        Button12.FlatAppearance.BorderSize = 0
        Button12.FlatAppearance.MouseDownBackColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        Button12.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        Button12.FlatStyle = FlatStyle.Flat
        Button12.Font = New Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button12.ForeColor = SystemColors.ControlLightLight
        Button12.Location = New Point(165, 226)
        Button12.Name = "Button12"
        Button12.Size = New Size(112, 34)
        Button12.TabIndex = 12
        Button12.Text = "Raise Ticket"
        Button12.UseVisualStyleBackColor = False
        ' 
        ' message
        ' 
        message.Location = New Point(165, 107)
        message.Multiline = True
        message.Name = "message"
        message.PlaceholderText = "Annaunce your message"
        message.Size = New Size(482, 71)
        message.TabIndex = 7
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Location = New Point(68, 141)
        Label8.Name = "Label8"
        Label8.Size = New Size(91, 25)
        Label8.TabIndex = 6
        Label8.Text = "message: "
        ' 
        ' user_id
        ' 
        user_id.Location = New Point(165, 38)
        user_id.Name = "user_id"
        user_id.PlaceholderText = "Enter user ID"
        user_id.Size = New Size(482, 31)
        user_id.TabIndex = 5
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Location = New Point(68, 44)
        Label9.Name = "Label9"
        Label9.Size = New Size(77, 25)
        Label9.TabIndex = 4
        Label9.Text = "user ID: "
        ' 
        ' Button6
        ' 
        Button6.BackColor = Color.CadetBlue
        Button6.FlatStyle = FlatStyle.Flat
        Button6.Font = New Font("SimSun", 10F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button6.ForeColor = SystemColors.ControlLightLight
        Button6.Location = New Point(3, 291)
        Button6.Name = "Button6"
        Button6.Size = New Size(303, 63)
        Button6.TabIndex = 12
        Button6.Text = "admin Annauncement"
        Button6.UseVisualStyleBackColor = False
        ' 
        ' Button7
        ' 
        Button7.BackColor = Color.LightSeaGreen
        Button7.FlatStyle = FlatStyle.Flat
        Button7.Font = New Font("SimSun", 10F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button7.ForeColor = Color.Azure
        Button7.Location = New Point(385, 289)
        Button7.Name = "Button7"
        Button7.Size = New Size(279, 65)
        Button7.TabIndex = 11
        Button7.Text = "CPs ticket Raised"
        Button7.UseVisualStyleBackColor = False
        ' 
        ' DataGridView1
        ' 
        DataGridView1.AllowUserToOrderColumns = True
        DataGridView1.BackgroundColor = Color.FromArgb(CByte(4), CByte(68), CByte(122))
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Location = New Point(5, 37)
        DataGridView1.MultiSelect = False
        DataGridView1.Name = "DataGridView1"
        DataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = Color.FromArgb(CByte(4), CByte(68), CByte(122))
        DataGridViewCellStyle2.Font = New Font("Segoe UI", 9F)
        DataGridViewCellStyle2.ForeColor = Color.White
        DataGridViewCellStyle2.SelectionBackColor = Color.CadetBlue
        DataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = DataGridViewTriState.True
        DataGridView1.RowHeadersDefaultCellStyle = DataGridViewCellStyle2
        DataGridView1.RowHeadersWidth = 62
        DataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        DataGridView1.Size = New Size(663, 248)
        DataGridView1.StandardTab = True
        DataGridView1.TabIndex = 1
        DataGridView1.VirtualMode = True
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Tahoma", 10F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label7.Location = New Point(3, 10)
        Label7.Name = "Label7"
        Label7.Size = New Size(197, 24)
        Label7.TabIndex = 0
        Label7.Text = "User's Tickets Raised"
        ' 
        ' ticketsForm
        ' 
        AutoScaleDimensions = New SizeF(10F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1200, 700)
        Controls.Add(Panel4)
        Controls.Add(Panel3)
        Controls.Add(Panel2)
        Controls.Add(Panel1)
        FormBorderStyle = FormBorderStyle.None
        Name = "ticketsForm"
        Text = "ticketsForm"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        pnlMain.ResumeLayout(False)
        pnlMain.PerformLayout()
        CType(dgvUsers, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        Panel3.ResumeLayout(False)
        Panel3.PerformLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        Panel4.ResumeLayout(False)
        Panel4.PerformLayout()
        Panel5.ResumeLayout(False)
        Panel5.PerformLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Button5 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents pnlMain As Panel
    Friend WithEvents dgvUsers As DataGridView
    Friend WithEvents lblTitle As Label
    Friend WithEvents Panel4 As Panel
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Label7 As Label
    Friend WithEvents Button7 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Button10 As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents message As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents user_id As TextBox
    Friend WithEvents Label9 As Label
End Class
