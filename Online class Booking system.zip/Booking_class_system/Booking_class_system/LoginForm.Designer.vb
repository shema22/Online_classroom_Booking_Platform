﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LoginForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(LoginForm))
        Panel1 = New Panel()
        Label2 = New Label()
        Label1 = New Label()
        Panel2 = New Panel()
        Panel4 = New Panel()
        Button1 = New Button()
        password = New TextBox()
        username = New TextBox()
        Label6 = New Label()
        Label5 = New Label()
        PictureBox1 = New PictureBox()
        Label4 = New Label()
        Panel3 = New Panel()
        Label3 = New Label()
        Panel1.SuspendLayout()
        Panel2.SuspendLayout()
        Panel4.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        Panel3.SuspendLayout()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = SystemColors.ControlLightLight
        Panel1.Controls.Add(Label2)
        Panel1.Controls.Add(Label1)
        Panel1.Dock = DockStyle.Top
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(915, 45)
        Panel1.TabIndex = 0
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Yu Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label2.ForeColor = Color.SteelBlue
        Label2.Location = New Point(0, 9)
        Label2.Name = "Label2"
        Label2.Size = New Size(543, 31)
        Label2.TabIndex = 1
        Label2.Text = "UR Huye Campus Online Class Booking System "
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = SystemColors.ControlLightLight
        Label1.BorderStyle = BorderStyle.Fixed3D
        Label1.Cursor = Cursors.Hand
        Label1.FlatStyle = FlatStyle.Flat
        Label1.Font = New Font("Tahoma", 11F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = Color.Brown
        Label1.Location = New Point(876, 9)
        Label1.Name = "Label1"
        Label1.Size = New Size(27, 29)
        Label1.TabIndex = 0
        Label1.Text = "X"
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.SteelBlue
        Panel2.Controls.Add(Panel4)
        Panel2.Controls.Add(Panel3)
        Panel2.Dock = DockStyle.Fill
        Panel2.Location = New Point(0, 45)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(915, 507)
        Panel2.TabIndex = 1
        ' 
        ' Panel4
        ' 
        Panel4.BackColor = Color.SteelBlue
        Panel4.BorderStyle = BorderStyle.Fixed3D
        Panel4.Controls.Add(Button1)
        Panel4.Controls.Add(password)
        Panel4.Controls.Add(username)
        Panel4.Controls.Add(Label6)
        Panel4.Controls.Add(Label5)
        Panel4.Controls.Add(PictureBox1)
        Panel4.Controls.Add(Label4)
        Panel4.Location = New Point(70, 33)
        Panel4.Name = "Panel4"
        Panel4.Size = New Size(723, 412)
        Panel4.TabIndex = 1
        ' 
        ' Button1
        ' 
        Button1.Cursor = Cursors.Hand
        Button1.FlatStyle = FlatStyle.Flat
        Button1.Font = New Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button1.ForeColor = SystemColors.ControlLightLight
        Button1.Location = New Point(203, 313)
        Button1.Name = "Button1"
        Button1.Size = New Size(339, 48)
        Button1.TabIndex = 6
        Button1.Text = "Login"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' password
        ' 
        password.Location = New Point(203, 244)
        password.Multiline = True
        password.Name = "password"
        password.Size = New Size(339, 46)
        password.TabIndex = 5
        ' 
        ' username
        ' 
        username.BorderStyle = BorderStyle.None
        username.Location = New Point(203, 172)
        username.Multiline = True
        username.Name = "username"
        username.Size = New Size(339, 46)
        username.TabIndex = 4
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label6.ForeColor = SystemColors.ControlLightLight
        Label6.Location = New Point(43, 261)
        Label6.Name = "Label6"
        Label6.Size = New Size(130, 29)
        Label6.TabIndex = 3
        Label6.Text = "Password :"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label5.ForeColor = SystemColors.ControlLightLight
        Label5.Location = New Point(43, 175)
        Label5.Name = "Label5"
        Label5.Size = New Size(137, 29)
        Label5.TabIndex = 2
        Label5.Text = "Username :"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), Image)
        PictureBox1.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox1.Location = New Point(281, 52)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(150, 96)
        PictureBox1.TabIndex = 1
        PictureBox1.TabStop = False
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Tahoma", 10F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label4.ForeColor = SystemColors.ControlLightLight
        Label4.Location = New Point(322, -2)
        Label4.Name = "Label4"
        Label4.Size = New Size(72, 24)
        Label4.TabIndex = 0
        Label4.Text = "Sign In"
        ' 
        ' Panel3
        ' 
        Panel3.BackColor = Color.Teal
        Panel3.Controls.Add(Label3)
        Panel3.Dock = DockStyle.Bottom
        Panel3.Location = New Point(0, 477)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(915, 30)
        Panel3.TabIndex = 0
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Microsoft Yi Baiti", 10F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label3.ForeColor = SystemColors.ControlLightLight
        Label3.Location = New Point(242, 0)
        Label3.Name = "Label3"
        Label3.Size = New Size(344, 20)
        Label3.TabIndex = 0
        Label3.Text = " Programming with client server & Alright reserve"
        ' 
        ' LoginForm
        ' 
        AutoScaleDimensions = New SizeF(10F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImageLayout = ImageLayout.None
        ClientSize = New Size(915, 552)
        Controls.Add(Panel2)
        Controls.Add(Panel1)
        FormBorderStyle = FormBorderStyle.None
        Name = "LoginForm"
        Text = "LoginForm"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        Panel2.ResumeLayout(False)
        Panel4.ResumeLayout(False)
        Panel4.PerformLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        Panel3.ResumeLayout(False)
        Panel3.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents password As TextBox
    Friend WithEvents username As TextBox
End Class
