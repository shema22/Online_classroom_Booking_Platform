﻿Imports MySql.Data.MySqlClient

Public Class dashboard
    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click
        Dim connectionString As String = "server=localhost;user id=root;password=;database=ur_huye_system"
        Using conn As New MySqlConnection(connectionString)
            Try
                conn.Open()
                Dim query As String = "SELECT SUM (user_id) FROM users"
                Using cmd As New MySqlCommand(query, conn)
                    cmd.ExecuteNonQuery()
                    MessageBox.Show(query)

                End Using
            Catch ex As MySqlException
                MessageBox.Show(ex.Message)

            End Try
        End Using
    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click
        Dim connectionString As String = "server=localhost;user id=root;password=;database=ur_huye_system"
        Using conn As New MySqlConnection(connectionString)
            Try
                conn.Open()
                Dim query As String = "SELECT SUM (classroom_id) FROM classrooms"
                Using cmd As New MySqlCommand(query, conn)
                    cmd.ExecuteNonQuery()
                    MessageBox.Show(query)

                End Using
            Catch ex As MySqlException
                MessageBox.Show(ex.Message)

            End Try
        End Using
    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click
        Dim connectionString As String = "server=localhost;user id=root;password=;database=ur_huye_system"
        Using conn As New MySqlConnection(connectionString)
            Try
                conn.Open()
                Dim query As String = "SELECT SUM (notification_id) FROM notifications"
                Using cmd As New MySqlCommand(query, conn)
                    cmd.ExecuteNonQuery()
                    MessageBox.Show(query)

                End Using
            Catch ex As MySqlException
                MessageBox.Show(ex.Message)

            End Try
        End Using
    End Sub

    Private Sub dashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Panel3_Paint(sender As Object, e As PaintEventArgs) Handles Panel3.Paint

    End Sub
End Class
