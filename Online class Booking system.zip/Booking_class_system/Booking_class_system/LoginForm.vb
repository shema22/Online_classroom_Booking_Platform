﻿Imports MySql.Data.MySqlClient

Public Class LoginForm
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim connectionString As String = "server=localhost;user id=root;password=;database=ur_huye_system"
        Using conn As New MySqlConnection(connectionString)
            Try
                conn.Open()
                Dim query As String = "SELECT * FROM users WHERE username = @username AND password = @password"
                Using cmd As New MySqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@username", username.Text)
                    cmd.Parameters.AddWithValue("@password", password.Text) ' Ideally, use hashed passwords
                    Using reader As MySqlDataReader = cmd.ExecuteReader()
                        If reader.HasRows Then
                            reader.Read()
                            Dim role As String = reader("role").ToString()

                            MessageBox.Show("Login successful!")
                            ' Navigate to Admin Dashboard
                            If role.ToLower() = "admin" Then
                                Dim adminDashboard As New mainForm()
                                adminDashboard.Show()
                            ElseIf role.ToLower() = "user" Then
                                Dim userDash As New userDashboard()
                                userDash.Show()
                            Else
                                MessageBox.Show("Invalid user role")
                                Exit Sub
                            End If

                            Me.Hide()
                        Else
                            MessageBox.Show("Invalid username or password.")
                        End If
                    End Using
                End Using
            Catch ex As MySqlException
                MessageBox.Show(ex.Message)

            End Try
        End Using
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click
        Application.Exit()
    End Sub
End Class
