﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class addUser
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As DataGridViewCellStyle = New DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(addUser))
        pnlMain = New Panel()
        dgvUsers = New DataGridView()
        lblTitle = New Label()
        pnlInput = New Panel()
        txtEmail = New TextBox()
        Label5 = New Label()
        btnDelete = New Button()
        btnClear = New Button()
        btnUpdate = New Button()
        btnAdd = New Button()
        cboRole = New ComboBox()
        lblRole = New Label()
        txtPassword = New TextBox()
        lblPassword = New Label()
        txtUsername = New TextBox()
        lblUsername = New Label()
        txtFullName = New TextBox()
        lblFullName = New Label()
        BackgroundWorker1 = New ComponentModel.BackgroundWorker()
        lblSystemTitle = New Label()
        Panel2 = New Panel()
        Button5 = New Button()
        Label4 = New Label()
        PictureBox2 = New PictureBox()
        Button3 = New Button()
        Button4 = New Button()
        Button2 = New Button()
        Button1 = New Button()
        Label1 = New Label()
        PictureBox1 = New PictureBox()
        Panel1 = New Panel()
        Label3 = New Label()
        Label2 = New Label()
        pnlMain.SuspendLayout()
        CType(dgvUsers, ComponentModel.ISupportInitialize).BeginInit()
        pnlInput.SuspendLayout()
        Panel2.SuspendLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        Panel1.SuspendLayout()
        SuspendLayout()
        ' 
        ' pnlMain
        ' 
        pnlMain.BackColor = Color.White
        pnlMain.BorderStyle = BorderStyle.FixedSingle
        pnlMain.Controls.Add(dgvUsers)
        pnlMain.Controls.Add(lblTitle)
        pnlMain.Location = New Point(334, 43)
        pnlMain.Name = "pnlMain"
        pnlMain.Size = New Size(854, 290)
        pnlMain.TabIndex = 0
        ' 
        ' dgvUsers
        ' 
        dgvUsers.AllowUserToOrderColumns = True
        dgvUsers.BackgroundColor = Color.FromArgb(CByte(4), CByte(68), CByte(122))
        dgvUsers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvUsers.Location = New Point(15, 37)
        dgvUsers.MultiSelect = False
        dgvUsers.Name = "dgvUsers"
        DataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = Color.FromArgb(CByte(4), CByte(68), CByte(122))
        DataGridViewCellStyle1.Font = New Font("Segoe UI", 9F)
        DataGridViewCellStyle1.ForeColor = Color.White
        DataGridViewCellStyle1.SelectionBackColor = Color.CadetBlue
        DataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = DataGridViewTriState.True
        dgvUsers.RowHeadersDefaultCellStyle = DataGridViewCellStyle1
        dgvUsers.RowHeadersWidth = 62
        dgvUsers.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgvUsers.Size = New Size(850, 248)
        dgvUsers.StandardTab = True
        dgvUsers.TabIndex = 1
        dgvUsers.VirtualMode = True
        ' 
        ' lblTitle
        ' 
        lblTitle.AutoSize = True
        lblTitle.Font = New Font("Tahoma", 10F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        lblTitle.Location = New Point(3, 10)
        lblTitle.Name = "lblTitle"
        lblTitle.Size = New Size(152, 24)
        lblTitle.TabIndex = 0
        lblTitle.Text = "CPs/User's Data"
        ' 
        ' pnlInput
        ' 
        pnlInput.BackColor = Color.White
        pnlInput.BorderStyle = BorderStyle.FixedSingle
        pnlInput.Controls.Add(txtEmail)
        pnlInput.Controls.Add(Label5)
        pnlInput.Controls.Add(btnDelete)
        pnlInput.Controls.Add(btnClear)
        pnlInput.Controls.Add(btnUpdate)
        pnlInput.Controls.Add(btnAdd)
        pnlInput.Controls.Add(cboRole)
        pnlInput.Controls.Add(lblRole)
        pnlInput.Controls.Add(txtPassword)
        pnlInput.Controls.Add(lblPassword)
        pnlInput.Controls.Add(txtUsername)
        pnlInput.Controls.Add(lblUsername)
        pnlInput.Controls.Add(txtFullName)
        pnlInput.Controls.Add(lblFullName)
        pnlInput.Location = New Point(334, 378)
        pnlInput.Name = "pnlInput"
        pnlInput.Size = New Size(854, 322)
        pnlInput.TabIndex = 1
        ' 
        ' txtEmail
        ' 
        txtEmail.Location = New Point(126, 111)
        txtEmail.Name = "txtEmail"
        txtEmail.PlaceholderText = "Enter valid Email"
        txtEmail.Size = New Size(334, 31)
        txtEmail.TabIndex = 17
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(16, 111)
        Label5.Name = "Label5"
        Label5.Size = New Size(63, 25)
        Label5.TabIndex = 16
        Label5.Text = "Email: "
        ' 
        ' btnDelete
        ' 
        btnDelete.BackColor = Color.SteelBlue
        btnDelete.FlatAppearance.BorderSize = 0
        btnDelete.FlatStyle = FlatStyle.Flat
        btnDelete.Font = New Font("Tahoma", 12F)
        btnDelete.ForeColor = Color.White
        btnDelete.Location = New Point(606, 261)
        btnDelete.Name = "btnDelete"
        btnDelete.Size = New Size(112, 34)
        btnDelete.TabIndex = 15
        btnDelete.Text = "Delete"
        btnDelete.UseVisualStyleBackColor = False
        ' 
        ' btnClear
        ' 
        btnClear.BackColor = Color.SteelBlue
        btnClear.FlatAppearance.BorderSize = 0
        btnClear.FlatStyle = FlatStyle.Flat
        btnClear.Font = New Font("Tahoma", 12F)
        btnClear.ForeColor = Color.White
        btnClear.Location = New Point(444, 261)
        btnClear.Name = "btnClear"
        btnClear.Size = New Size(112, 34)
        btnClear.TabIndex = 14
        btnClear.Text = "Clear"
        btnClear.UseVisualStyleBackColor = False
        ' 
        ' btnUpdate
        ' 
        btnUpdate.BackColor = Color.SteelBlue
        btnUpdate.FlatAppearance.BorderSize = 0
        btnUpdate.FlatStyle = FlatStyle.Flat
        btnUpdate.Font = New Font("Tahoma", 12F)
        btnUpdate.ForeColor = Color.White
        btnUpdate.Location = New Point(288, 261)
        btnUpdate.Name = "btnUpdate"
        btnUpdate.Size = New Size(112, 34)
        btnUpdate.TabIndex = 13
        btnUpdate.Text = "Update"
        btnUpdate.UseVisualStyleBackColor = False
        ' 
        ' btnAdd
        ' 
        btnAdd.BackColor = Color.SteelBlue
        btnAdd.FlatAppearance.BorderSize = 0
        btnAdd.FlatStyle = FlatStyle.Flat
        btnAdd.Font = New Font("Tahoma", 12F)
        btnAdd.ForeColor = Color.White
        btnAdd.Location = New Point(126, 261)
        btnAdd.Name = "btnAdd"
        btnAdd.Size = New Size(112, 34)
        btnAdd.TabIndex = 12
        btnAdd.Text = "ADD"
        btnAdd.UseVisualStyleBackColor = False
        ' 
        ' cboRole
        ' 
        cboRole.FormattingEnabled = True
        cboRole.Items.AddRange(New Object() {"admin", "user"})
        cboRole.Location = New Point(126, 195)
        cboRole.Name = "cboRole"
        cboRole.Size = New Size(334, 33)
        cboRole.TabIndex = 11
        ' 
        ' lblRole
        ' 
        lblRole.AutoSize = True
        lblRole.Location = New Point(16, 195)
        lblRole.Name = "lblRole"
        lblRole.Size = New Size(55, 25)
        lblRole.TabIndex = 10
        lblRole.Text = "Role: "
        ' 
        ' txtPassword
        ' 
        txtPassword.Location = New Point(126, 148)
        txtPassword.Name = "txtPassword"
        txtPassword.PlaceholderText = "Enter password"
        txtPassword.Size = New Size(334, 31)
        txtPassword.TabIndex = 9
        txtPassword.UseSystemPasswordChar = True
        ' 
        ' lblPassword
        ' 
        lblPassword.AutoSize = True
        lblPassword.Location = New Point(16, 148)
        lblPassword.Name = "lblPassword"
        lblPassword.Size = New Size(96, 25)
        lblPassword.TabIndex = 8
        lblPassword.Text = "Password: "
        ' 
        ' txtUsername
        ' 
        txtUsername.Location = New Point(126, 68)
        txtUsername.Name = "txtUsername"
        txtUsername.PlaceholderText = "username.. g.e reg_no"
        txtUsername.Size = New Size(334, 31)
        txtUsername.TabIndex = 7
        ' 
        ' lblUsername
        ' 
        lblUsername.AutoSize = True
        lblUsername.Location = New Point(16, 68)
        lblUsername.Name = "lblUsername"
        lblUsername.Size = New Size(100, 25)
        lblUsername.TabIndex = 6
        lblUsername.Text = "Username: "
        ' 
        ' txtFullName
        ' 
        txtFullName.Location = New Point(126, 17)
        txtFullName.Name = "txtFullName"
        txtFullName.PlaceholderText = "Enter full Names"
        txtFullName.Size = New Size(334, 31)
        txtFullName.TabIndex = 5
        ' 
        ' lblFullName
        ' 
        lblFullName.AutoSize = True
        lblFullName.Location = New Point(16, 17)
        lblFullName.Name = "lblFullName"
        lblFullName.Size = New Size(100, 25)
        lblFullName.TabIndex = 4
        lblFullName.Text = "Full Name: "
        ' 
        ' lblSystemTitle
        ' 
        lblSystemTitle.Location = New Point(0, 0)
        lblSystemTitle.Name = "lblSystemTitle"
        lblSystemTitle.Size = New Size(100, 23)
        lblSystemTitle.TabIndex = 0
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.SteelBlue
        Panel2.BorderStyle = BorderStyle.Fixed3D
        Panel2.Controls.Add(Button5)
        Panel2.Controls.Add(Label4)
        Panel2.Controls.Add(PictureBox2)
        Panel2.Controls.Add(Button3)
        Panel2.Controls.Add(Button4)
        Panel2.Controls.Add(Button2)
        Panel2.Controls.Add(Button1)
        Panel2.Controls.Add(Label1)
        Panel2.Controls.Add(PictureBox1)
        Panel2.Dock = DockStyle.Left
        Panel2.Location = New Point(0, 0)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(300, 700)
        Panel2.TabIndex = 5
        ' 
        ' Button5
        ' 
        Button5.Cursor = Cursors.Hand
        Button5.FlatAppearance.MouseDownBackColor = Color.FromArgb(CByte(192), CByte(0), CByte(0))
        Button5.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(192), CByte(0), CByte(0))
        Button5.FlatStyle = FlatStyle.Flat
        Button5.Font = New Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button5.ForeColor = SystemColors.ControlLightLight
        Button5.Image = CType(resources.GetObject("Button5.Image"), Image)
        Button5.ImageAlign = ContentAlignment.MiddleLeft
        Button5.Location = New Point(30, 500)
        Button5.Name = "Button5"
        Button5.Size = New Size(241, 50)
        Button5.TabIndex = 7
        Button5.Text = "Booking status"
        Button5.TextAlign = ContentAlignment.MiddleRight
        Button5.UseVisualStyleBackColor = True
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Tahoma", 9F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label4.ForeColor = SystemColors.ControlLightLight
        Label4.Location = New Point(58, 638)
        Label4.Name = "Label4"
        Label4.Size = New Size(65, 22)
        Label4.TabIndex = 6
        Label4.Text = "Logout"
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), Image)
        PictureBox2.Location = New Point(-2, 634)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(58, 26)
        PictureBox2.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox2.TabIndex = 1
        PictureBox2.TabStop = False
        ' 
        ' Button3
        ' 
        Button3.Cursor = Cursors.Hand
        Button3.FlatAppearance.MouseDownBackColor = Color.FromArgb(CByte(192), CByte(0), CByte(0))
        Button3.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(192), CByte(0), CByte(0))
        Button3.FlatStyle = FlatStyle.Flat
        Button3.Font = New Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button3.ForeColor = SystemColors.ControlLightLight
        Button3.Image = CType(resources.GetObject("Button3.Image"), Image)
        Button3.ImageAlign = ContentAlignment.MiddleLeft
        Button3.Location = New Point(30, 432)
        Button3.Name = "Button3"
        Button3.Size = New Size(241, 50)
        Button3.TabIndex = 5
        Button3.Text = "Announcement " & vbCrLf
        Button3.TextAlign = ContentAlignment.MiddleRight
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Button4
        ' 
        Button4.Cursor = Cursors.Hand
        Button4.FlatStyle = FlatStyle.Flat
        Button4.Font = New Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button4.ForeColor = SystemColors.ControlLightLight
        Button4.Image = CType(resources.GetObject("Button4.Image"), Image)
        Button4.ImageAlign = ContentAlignment.MiddleLeft
        Button4.Location = New Point(30, 376)
        Button4.Name = "Button4"
        Button4.Size = New Size(241, 50)
        Button4.TabIndex = 4
        Button4.Text = " Classroom"
        Button4.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Cursor = Cursors.Hand
        Button2.FlatAppearance.MouseDownBackColor = Color.DarkSeaGreen
        Button2.FlatAppearance.MouseOverBackColor = Color.DarkSeaGreen
        Button2.FlatStyle = FlatStyle.Flat
        Button2.Font = New Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button2.ForeColor = SystemColors.ControlLightLight
        Button2.Image = CType(resources.GetObject("Button2.Image"), Image)
        Button2.ImageAlign = ContentAlignment.MiddleLeft
        Button2.Location = New Point(30, 306)
        Button2.Name = "Button2"
        Button2.Size = New Size(241, 50)
        Button2.TabIndex = 3
        Button2.Text = " CPs / User"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button1
        ' 
        Button1.Cursor = Cursors.Hand
        Button1.FlatAppearance.BorderColor = Color.White
        Button1.FlatAppearance.MouseDownBackColor = Color.FromArgb(CByte(0), CByte(192), CByte(192))
        Button1.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(0), CByte(192), CByte(192))
        Button1.FlatStyle = FlatStyle.Flat
        Button1.Font = New Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button1.ForeColor = SystemColors.ControlLightLight
        Button1.Image = CType(resources.GetObject("Button1.Image"), Image)
        Button1.ImageAlign = ContentAlignment.MiddleLeft
        Button1.Location = New Point(25, 235)
        Button1.Name = "Button1"
        Button1.Size = New Size(241, 50)
        Button1.TabIndex = 2
        Button1.Text = "dashboard"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Bahnschrift", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = SystemColors.ControlLightLight
        Label1.Location = New Point(58, 173)
        Label1.Name = "Label1"
        Label1.Size = New Size(191, 29)
        Label1.TabIndex = 2
        Label1.Text = "welcome, Admin"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(58, 29)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(186, 123)
        PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox1.TabIndex = 2
        PictureBox1.TabStop = False
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.FromArgb(CByte(4), CByte(68), CByte(122))
        Panel1.Controls.Add(Label3)
        Panel1.Controls.Add(Label2)
        Panel1.Dock = DockStyle.Top
        Panel1.Location = New Point(300, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(900, 37)
        Panel1.TabIndex = 6
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.ForeColor = Color.White
        Label3.Location = New Point(862, 4)
        Label3.Name = "Label3"
        Label3.Size = New Size(26, 27)
        Label3.TabIndex = 1
        Label3.Text = "X"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Courier New", 10F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label2.ForeColor = Color.White
        Label2.Location = New Point(6, 9)
        Label2.Name = "Label2"
        Label2.Size = New Size(526, 22)
        Label2.TabIndex = 0
        Label2.Text = "UR Huye Campus Online Class Booking System "
        ' 
        ' addUser
        ' 
        AutoScaleDimensions = New SizeF(10F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImageLayout = ImageLayout.None
        ClientSize = New Size(1200, 700)
        Controls.Add(Panel1)
        Controls.Add(Panel2)
        Controls.Add(pnlInput)
        Controls.Add(pnlMain)
        FormBorderStyle = FormBorderStyle.None
        Name = "addUser"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Add User"
        pnlMain.ResumeLayout(False)
        pnlMain.PerformLayout()
        CType(dgvUsers, ComponentModel.ISupportInitialize).EndInit()
        pnlInput.ResumeLayout(False)
        pnlInput.PerformLayout()
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents pnlMain As Panel
    Friend WithEvents lblTitle As Label
    Friend WithEvents pnlInput As Panel
    Friend WithEvents dgvUsers As DataGridView
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents cboRole As ComboBox
    Friend WithEvents lblRole As Label
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents lblPassword As Label
    Friend WithEvents txtUsername As TextBox
    Friend WithEvents lblUsername As Label
    Friend WithEvents txtFullName As TextBox
    Friend WithEvents lblFullName As Label
    Friend WithEvents btnAdd As Button
    Friend WithEvents btnDelete As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnUpdate As Button
    Friend WithEvents lblSystemTitle As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Button5 As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label3 As Label
End Class