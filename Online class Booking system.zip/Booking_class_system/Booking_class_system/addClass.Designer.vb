﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class addClass
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Panel2 = New Panel()
        class_details = New TextBox()
        Label2 = New Label()
        class_location = New TextBox()
        Label6 = New Label()
        class_deletebtn = New Button()
        class_clearbtn = New Button()
        class_updatebtn = New Button()
        class_addbtn = New Button()
        class_status = New ComboBox()
        Label3 = New Label()
        class_size = New TextBox()
        Label5 = New Label()
        class_name = New TextBox()
        Label4 = New Label()
        Panel1 = New Panel()
        class_DataGridView = New DataGridView()
        Label1 = New Label()
        Panel2.SuspendLayout()
        Panel1.SuspendLayout()
        CType(class_DataGridView, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.White
        Panel2.BorderStyle = BorderStyle.FixedSingle
        Panel2.Controls.Add(class_details)
        Panel2.Controls.Add(Label2)
        Panel2.Controls.Add(class_location)
        Panel2.Controls.Add(Label6)
        Panel2.Controls.Add(class_deletebtn)
        Panel2.Controls.Add(class_clearbtn)
        Panel2.Controls.Add(class_updatebtn)
        Panel2.Controls.Add(class_addbtn)
        Panel2.Controls.Add(class_status)
        Panel2.Controls.Add(Label3)
        Panel2.Controls.Add(class_size)
        Panel2.Controls.Add(Label5)
        Panel2.Controls.Add(class_name)
        Panel2.Controls.Add(Label4)
        Panel2.Location = New Point(23, 329)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(854, 316)
        Panel2.TabIndex = 3
        ' 
        ' class_details
        ' 
        class_details.Location = New Point(126, 232)
        class_details.Name = "class_details"
        class_details.Size = New Size(334, 31)
        class_details.TabIndex = 19
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(17, 232)
        Label2.Name = "Label2"
        Label2.Size = New Size(74, 25)
        Label2.TabIndex = 18
        Label2.Text = "Details: "
        ' 
        ' class_location
        ' 
        class_location.Location = New Point(126, 178)
        class_location.Name = "class_location"
        class_location.Size = New Size(334, 31)
        class_location.TabIndex = 17
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Location = New Point(17, 178)
        Label6.Name = "Label6"
        Label6.Size = New Size(88, 25)
        Label6.TabIndex = 16
        Label6.Text = "Location: "
        ' 
        ' class_deletebtn
        ' 
        class_deletebtn.BackColor = Color.SteelBlue
        class_deletebtn.FlatAppearance.BorderSize = 0
        class_deletebtn.FlatAppearance.MouseDownBackColor = Color.FromArgb(CByte(192), CByte(0), CByte(0))
        class_deletebtn.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(192), CByte(0), CByte(0))
        class_deletebtn.FlatStyle = FlatStyle.Flat
        class_deletebtn.Font = New Font("Tahoma", 12.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        class_deletebtn.ForeColor = SystemColors.ControlLightLight
        class_deletebtn.Location = New Point(550, 232)
        class_deletebtn.Name = "class_deletebtn"
        class_deletebtn.Size = New Size(112, 34)
        class_deletebtn.TabIndex = 15
        class_deletebtn.Text = "Delete"
        class_deletebtn.UseVisualStyleBackColor = False
        ' 
        ' class_clearbtn
        ' 
        class_clearbtn.BackColor = Color.SteelBlue
        class_clearbtn.FlatAppearance.BorderSize = 0
        class_clearbtn.FlatAppearance.MouseDownBackColor = Color.Blue
        class_clearbtn.FlatAppearance.MouseOverBackColor = Color.Blue
        class_clearbtn.FlatStyle = FlatStyle.Flat
        class_clearbtn.Font = New Font("Tahoma", 12.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        class_clearbtn.ForeColor = SystemColors.ControlLightLight
        class_clearbtn.Location = New Point(550, 156)
        class_clearbtn.Name = "class_clearbtn"
        class_clearbtn.Size = New Size(112, 34)
        class_clearbtn.TabIndex = 14
        class_clearbtn.Text = "clear"
        class_clearbtn.UseVisualStyleBackColor = False
        ' 
        ' class_updatebtn
        ' 
        class_updatebtn.BackColor = Color.SteelBlue
        class_updatebtn.FlatAppearance.BorderSize = 0
        class_updatebtn.FlatAppearance.MouseDownBackColor = Color.Teal
        class_updatebtn.FlatAppearance.MouseOverBackColor = Color.Teal
        class_updatebtn.FlatStyle = FlatStyle.Flat
        class_updatebtn.Font = New Font("Tahoma", 12.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        class_updatebtn.ForeColor = SystemColors.ControlLightLight
        class_updatebtn.Location = New Point(550, 89)
        class_updatebtn.Name = "class_updatebtn"
        class_updatebtn.Size = New Size(112, 34)
        class_updatebtn.TabIndex = 13
        class_updatebtn.Text = "Update"
        class_updatebtn.UseVisualStyleBackColor = False
        ' 
        ' class_addbtn
        ' 
        class_addbtn.BackColor = Color.SteelBlue
        class_addbtn.FlatAppearance.BorderSize = 0
        class_addbtn.FlatAppearance.MouseDownBackColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        class_addbtn.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        class_addbtn.FlatStyle = FlatStyle.Flat
        class_addbtn.Font = New Font("Tahoma", 12.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        class_addbtn.ForeColor = SystemColors.ControlLightLight
        class_addbtn.Location = New Point(550, 17)
        class_addbtn.Name = "class_addbtn"
        class_addbtn.Size = New Size(112, 34)
        class_addbtn.TabIndex = 12
        class_addbtn.Text = "ADD"
        class_addbtn.UseVisualStyleBackColor = False
        ' 
        ' class_status
        ' 
        class_status.FormattingEnabled = True
        class_status.Items.AddRange(New Object() {"free", "booked"})
        class_status.Location = New Point(126, 123)
        class_status.Name = "class_status"
        class_status.Size = New Size(334, 33)
        class_status.TabIndex = 11
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(16, 126)
        Label3.Name = "Label3"
        Label3.Size = New Size(69, 25)
        Label3.TabIndex = 10
        Label3.Text = "Status: "
        ' 
        ' class_size
        ' 
        class_size.Location = New Point(126, 68)
        class_size.Name = "class_size"
        class_size.Size = New Size(334, 31)
        class_size.TabIndex = 7
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(16, 68)
        Label5.Name = "Label5"
        Label5.Size = New Size(97, 25)
        Label5.TabIndex = 6
        Label5.Text = "Class Size: "
        ' 
        ' class_name
        ' 
        class_name.Location = New Point(126, 17)
        class_name.Name = "class_name"
        class_name.Size = New Size(334, 31)
        class_name.TabIndex = 5
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(16, 17)
        Label4.Name = "Label4"
        Label4.Size = New Size(110, 25)
        Label4.TabIndex = 4
        Label4.Text = "class Name: "
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.White
        Panel1.BorderStyle = BorderStyle.FixedSingle
        Panel1.Controls.Add(class_DataGridView)
        Panel1.Controls.Add(Label1)
        Panel1.Location = New Point(23, 17)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(854, 290)
        Panel1.TabIndex = 2
        ' 
        ' class_DataGridView
        ' 
        class_DataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        class_DataGridView.Location = New Point(3, 37)
        class_DataGridView.Name = "class_DataGridView"
        class_DataGridView.RowHeadersWidth = 62
        class_DataGridView.Size = New Size(850, 248)
        class_DataGridView.TabIndex = 1
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Tahoma", 10.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(3, 10)
        Label1.Name = "Label1"
        Label1.Size = New Size(164, 24)
        Label1.TabIndex = 0
        Label1.Text = "Classroom's Data"
        ' 
        ' addClass
        ' 
        AutoScaleDimensions = New SizeF(10.0F, 25.0F)
        AutoScaleMode = AutoScaleMode.Font
        Controls.Add(Panel2)
        Controls.Add(Panel1)
        Name = "addClass"
        Size = New Size(900, 662)
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        CType(class_DataGridView, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel2 As Panel
    Friend WithEvents class_deletebtn As Button
    Friend WithEvents class_clearbtn As Button
    Friend WithEvents class_updatebtn As Button
    Friend WithEvents class_addbtn As Button
    Friend WithEvents class_status As ComboBox
    Friend WithEvents Label3 As Label
    Friend WithEvents class_size As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents class_name As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents class_DataGridView As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents class_details As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents class_location As TextBox
    Friend WithEvents Label6 As Label

End Class
