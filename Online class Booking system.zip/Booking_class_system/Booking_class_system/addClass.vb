﻿Imports MySql.Data.MySqlClient
Imports System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel

Public Class addClass
    Private Sub class_addbtn_Click(sender As Object, e As EventArgs) Handles class_addbtn.Click
        Dim connectionString As String = "server=localhost;user id=root;password=;database=ur_huye_system"
        Using conn As New MySqlConnection(connectionString)
            Try
                conn.Open()
                Dim query As String = "INSERT INTO classrooms (name, size, status, location, details) VALUES (@class_name, @class_size, @class_status, @class_location, @class_details)"
                Using cmd As New MySqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@class_name", class_name.Text)
                    cmd.Parameters.AddWithValue("@class_size", class_size.Text)
                    cmd.Parameters.AddWithValue("@class_status", class_status.Text)
                    cmd.Parameters.AddWithValue("@class_location", class_location.Text)
                    cmd.Parameters.AddWithValue("@class_details", class_details.Text)
                    cmd.ExecuteNonQuery()
                    MessageBox.Show("Classroom added successfully!")

                End Using
            Catch ex As MySqlException
                MessageBox.Show(ex.Message)

            End Try
        End Using
    End Sub
End Class
