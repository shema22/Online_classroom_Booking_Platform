﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class addticketsForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(addticketsForm))
        Dim DataGridViewCellStyle2 As DataGridViewCellStyle = New DataGridViewCellStyle()
        Panel2 = New Panel()
        Button5 = New Button()
        Label4 = New Label()
        PictureBox2 = New PictureBox()
        Button3 = New Button()
        Button4 = New Button()
        Button2 = New Button()
        Button1 = New Button()
        Label1 = New Label()
        PictureBox1 = New PictureBox()
        Panel4 = New Panel()
        btnDelete = New Button()
        Button10 = New Button()
        btnUpdate = New Button()
        Button12 = New Button()
        message = New TextBox()
        Label7 = New Label()
        user_id = New TextBox()
        Label2 = New Label()
        Panel5 = New Panel()
        Label5 = New Label()
        dgvNotifications = New DataGridView()
        Label9 = New Label()
        Button6 = New Button()
        cp = New Button()
        Panel2.SuspendLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        Panel4.SuspendLayout()
        Panel5.SuspendLayout()
        CType(dgvNotifications, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.SteelBlue
        Panel2.BorderStyle = BorderStyle.Fixed3D
        Panel2.Controls.Add(Button5)
        Panel2.Controls.Add(Label4)
        Panel2.Controls.Add(PictureBox2)
        Panel2.Controls.Add(Button3)
        Panel2.Controls.Add(Button4)
        Panel2.Controls.Add(Button2)
        Panel2.Controls.Add(Button1)
        Panel2.Controls.Add(Label1)
        Panel2.Controls.Add(PictureBox1)
        Panel2.Dock = DockStyle.Left
        Panel2.Location = New Point(0, 0)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(300, 700)
        Panel2.TabIndex = 6
        ' 
        ' Button5
        ' 
        Button5.Cursor = Cursors.Hand
        Button5.FlatAppearance.MouseDownBackColor = Color.FromArgb(CByte(192), CByte(0), CByte(0))
        Button5.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(192), CByte(0), CByte(0))
        Button5.FlatStyle = FlatStyle.Flat
        Button5.Font = New Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button5.ForeColor = SystemColors.ControlLightLight
        Button5.Image = CType(resources.GetObject("Button5.Image"), Image)
        Button5.ImageAlign = ContentAlignment.MiddleLeft
        Button5.Location = New Point(30, 500)
        Button5.Name = "Button5"
        Button5.Size = New Size(241, 50)
        Button5.TabIndex = 7
        Button5.Text = "Booking status"
        Button5.TextAlign = ContentAlignment.MiddleRight
        Button5.UseVisualStyleBackColor = True
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Tahoma", 9F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label4.ForeColor = SystemColors.ControlLightLight
        Label4.Location = New Point(58, 638)
        Label4.Name = "Label4"
        Label4.Size = New Size(65, 22)
        Label4.TabIndex = 6
        Label4.Text = "Logout"
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), Image)
        PictureBox2.Location = New Point(-2, 634)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(58, 26)
        PictureBox2.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox2.TabIndex = 1
        PictureBox2.TabStop = False
        ' 
        ' Button3
        ' 
        Button3.Cursor = Cursors.Hand
        Button3.FlatAppearance.MouseDownBackColor = Color.FromArgb(CByte(192), CByte(0), CByte(0))
        Button3.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(192), CByte(0), CByte(0))
        Button3.FlatStyle = FlatStyle.Flat
        Button3.Font = New Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button3.ForeColor = SystemColors.ControlLightLight
        Button3.Image = CType(resources.GetObject("Button3.Image"), Image)
        Button3.ImageAlign = ContentAlignment.MiddleLeft
        Button3.Location = New Point(30, 432)
        Button3.Name = "Button3"
        Button3.Size = New Size(241, 50)
        Button3.TabIndex = 5
        Button3.Text = "Announcement " & vbCrLf
        Button3.TextAlign = ContentAlignment.MiddleRight
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Button4
        ' 
        Button4.Cursor = Cursors.Hand
        Button4.FlatStyle = FlatStyle.Flat
        Button4.Font = New Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button4.ForeColor = SystemColors.ControlLightLight
        Button4.Image = CType(resources.GetObject("Button4.Image"), Image)
        Button4.ImageAlign = ContentAlignment.MiddleLeft
        Button4.Location = New Point(30, 376)
        Button4.Name = "Button4"
        Button4.Size = New Size(241, 50)
        Button4.TabIndex = 4
        Button4.Text = " Classroom"
        Button4.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Cursor = Cursors.Hand
        Button2.FlatAppearance.MouseDownBackColor = Color.DarkSeaGreen
        Button2.FlatAppearance.MouseOverBackColor = Color.DarkSeaGreen
        Button2.FlatStyle = FlatStyle.Flat
        Button2.Font = New Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button2.ForeColor = SystemColors.ControlLightLight
        Button2.Image = CType(resources.GetObject("Button2.Image"), Image)
        Button2.ImageAlign = ContentAlignment.MiddleLeft
        Button2.Location = New Point(30, 306)
        Button2.Name = "Button2"
        Button2.Size = New Size(241, 50)
        Button2.TabIndex = 3
        Button2.Text = " CPs / User"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button1
        ' 
        Button1.Cursor = Cursors.Hand
        Button1.FlatAppearance.BorderColor = Color.White
        Button1.FlatAppearance.MouseDownBackColor = Color.FromArgb(CByte(0), CByte(192), CByte(192))
        Button1.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(0), CByte(192), CByte(192))
        Button1.FlatStyle = FlatStyle.Flat
        Button1.Font = New Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button1.ForeColor = SystemColors.ControlLightLight
        Button1.Image = CType(resources.GetObject("Button1.Image"), Image)
        Button1.ImageAlign = ContentAlignment.MiddleLeft
        Button1.Location = New Point(25, 235)
        Button1.Name = "Button1"
        Button1.Size = New Size(241, 50)
        Button1.TabIndex = 2
        Button1.Text = "Dashboard"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Bahnschrift", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = SystemColors.ControlLightLight
        Label1.Location = New Point(58, 173)
        Label1.Name = "Label1"
        Label1.Size = New Size(191, 29)
        Label1.TabIndex = 2
        Label1.Text = "welcome, Admin"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(58, 29)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(186, 123)
        PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox1.TabIndex = 2
        PictureBox1.TabStop = False
        ' 
        ' Panel4
        ' 
        Panel4.BackColor = Color.White
        Panel4.BorderStyle = BorderStyle.FixedSingle
        Panel4.Controls.Add(btnDelete)
        Panel4.Controls.Add(Button10)
        Panel4.Controls.Add(btnUpdate)
        Panel4.Controls.Add(Button12)
        Panel4.Controls.Add(message)
        Panel4.Controls.Add(Label7)
        Panel4.Controls.Add(user_id)
        Panel4.Controls.Add(Label2)
        Panel4.Location = New Point(306, 412)
        Panel4.Name = "Panel4"
        Panel4.Size = New Size(882, 282)
        Panel4.TabIndex = 7
        ' 
        ' btnDelete
        ' 
        btnDelete.BackColor = Color.SteelBlue
        btnDelete.FlatAppearance.BorderSize = 0
        btnDelete.FlatAppearance.MouseDownBackColor = Color.FromArgb(CByte(192), CByte(0), CByte(0))
        btnDelete.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(192), CByte(0), CByte(0))
        btnDelete.FlatStyle = FlatStyle.Flat
        btnDelete.Font = New Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        btnDelete.ForeColor = SystemColors.ControlLightLight
        btnDelete.Location = New Point(606, 226)
        btnDelete.Name = "btnDelete"
        btnDelete.Size = New Size(112, 34)
        btnDelete.TabIndex = 15
        btnDelete.Text = "Delete"
        btnDelete.UseVisualStyleBackColor = False
        ' 
        ' Button10
        ' 
        Button10.BackColor = Color.SteelBlue
        Button10.FlatAppearance.BorderSize = 0
        Button10.FlatAppearance.MouseDownBackColor = Color.Blue
        Button10.FlatAppearance.MouseOverBackColor = Color.Blue
        Button10.FlatStyle = FlatStyle.Flat
        Button10.Font = New Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button10.ForeColor = SystemColors.ControlLightLight
        Button10.Location = New Point(444, 226)
        Button10.Name = "Button10"
        Button10.Size = New Size(112, 34)
        Button10.TabIndex = 14
        Button10.Text = "clear"
        Button10.UseVisualStyleBackColor = False
        ' 
        ' btnUpdate
        ' 
        btnUpdate.BackColor = Color.SteelBlue
        btnUpdate.FlatAppearance.BorderSize = 0
        btnUpdate.FlatAppearance.MouseDownBackColor = Color.Teal
        btnUpdate.FlatAppearance.MouseOverBackColor = Color.Teal
        btnUpdate.FlatStyle = FlatStyle.Flat
        btnUpdate.Font = New Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        btnUpdate.ForeColor = SystemColors.ControlLightLight
        btnUpdate.Location = New Point(288, 226)
        btnUpdate.Name = "btnUpdate"
        btnUpdate.Size = New Size(112, 34)
        btnUpdate.TabIndex = 13
        btnUpdate.Text = "Update"
        btnUpdate.UseVisualStyleBackColor = False
        ' 
        ' Button12
        ' 
        Button12.BackColor = Color.SteelBlue
        Button12.FlatAppearance.BorderSize = 0
        Button12.FlatAppearance.MouseDownBackColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        Button12.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        Button12.FlatStyle = FlatStyle.Flat
        Button12.Font = New Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button12.ForeColor = SystemColors.ControlLightLight
        Button12.Location = New Point(126, 226)
        Button12.Name = "Button12"
        Button12.Size = New Size(112, 34)
        Button12.TabIndex = 12
        Button12.Text = "ADD"
        Button12.UseVisualStyleBackColor = False
        ' 
        ' message
        ' 
        message.Location = New Point(236, 123)
        message.Multiline = True
        message.Name = "message"
        message.PlaceholderText = "Annaunce your message"
        message.Size = New Size(482, 71)
        message.TabIndex = 7
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Location = New Point(114, 129)
        Label7.Name = "Label7"
        Label7.Size = New Size(91, 25)
        Label7.TabIndex = 6
        Label7.Text = "message: "
        ' 
        ' user_id
        ' 
        user_id.Location = New Point(236, 38)
        user_id.Name = "user_id"
        user_id.PlaceholderText = "Enter user ID"
        user_id.Size = New Size(482, 31)
        user_id.TabIndex = 5
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(126, 38)
        Label2.Name = "Label2"
        Label2.Size = New Size(77, 25)
        Label2.TabIndex = 4
        Label2.Text = "user ID: "
        ' 
        ' Panel5
        ' 
        Panel5.BackColor = Color.White
        Panel5.BorderStyle = BorderStyle.FixedSingle
        Panel5.Controls.Add(Label5)
        Panel5.Controls.Add(dgvNotifications)
        Panel5.Controls.Add(Label9)
        Panel5.Location = New Point(316, 12)
        Panel5.Name = "Panel5"
        Panel5.Size = New Size(872, 290)
        Panel5.TabIndex = 8
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Algerian", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label5.ForeColor = Color.FromArgb(CByte(192), CByte(0), CByte(0))
        Label5.Location = New Point(837, 8)
        Label5.Name = "Label5"
        Label5.Size = New Size(30, 26)
        Label5.TabIndex = 11
        Label5.Text = "X"
        ' 
        ' dgvNotifications
        ' 
        dgvNotifications.BackgroundColor = Color.CadetBlue
        dgvNotifications.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = SystemColors.Window
        DataGridViewCellStyle2.Font = New Font("Segoe UI", 9F)
        DataGridViewCellStyle2.ForeColor = SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = DataGridViewTriState.False
        dgvNotifications.DefaultCellStyle = DataGridViewCellStyle2
        dgvNotifications.GridColor = Color.White
        dgvNotifications.Location = New Point(3, 37)
        dgvNotifications.MultiSelect = False
        dgvNotifications.Name = "dgvNotifications"
        dgvNotifications.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.Sunken
        dgvNotifications.RowHeadersVisible = False
        dgvNotifications.RowHeadersWidth = 62
        dgvNotifications.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgvNotifications.Size = New Size(868, 248)
        dgvNotifications.TabIndex = 1
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Tahoma", 10F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label9.Location = New Point(13, 10)
        Label9.Name = "Label9"
        Label9.Size = New Size(126, 24)
        Label9.TabIndex = 0
        Label9.Text = "Ticket's Data"
        ' 
        ' Button6
        ' 
        Button6.FlatStyle = FlatStyle.Flat
        Button6.ForeColor = SystemColors.ControlLightLight
        Button6.Location = New Point(316, 321)
        Button6.Name = "Button6"
        Button6.Size = New Size(391, 65)
        Button6.TabIndex = 9
        Button6.Text = "admin Annauncement"
        Button6.UseVisualStyleBackColor = True
        ' 
        ' cp
        ' 
        cp.FlatStyle = FlatStyle.Flat
        cp.ForeColor = SystemColors.ControlLightLight
        cp.Location = New Point(773, 321)
        cp.Name = "cp"
        cp.Size = New Size(415, 65)
        cp.TabIndex = 10
        cp.Text = "CPs ticket Raised"
        cp.UseVisualStyleBackColor = True
        ' 
        ' addticketsForm
        ' 
        AutoScaleDimensions = New SizeF(10F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(4), CByte(68), CByte(122))
        ClientSize = New Size(1200, 700)
        Controls.Add(cp)
        Controls.Add(Button6)
        Controls.Add(Panel5)
        Controls.Add(Panel4)
        Controls.Add(Panel2)
        FormBorderStyle = FormBorderStyle.None
        Name = "addticketsForm"
        Text = "addticketsForm"
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        Panel4.ResumeLayout(False)
        Panel4.PerformLayout()
        Panel5.ResumeLayout(False)
        Panel5.PerformLayout()
        CType(dgvNotifications, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Button5 As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Panel4 As Panel
    Friend WithEvents btnDelete As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents btnUpdate As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents message As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents user_id As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Panel5 As Panel
    Friend WithEvents dgvNotifications As DataGridView
    Friend WithEvents Label9 As Label
    Friend WithEvents Button6 As Button
    Friend WithEvents cp As Button
    Friend WithEvents Label5 As Label
End Class
