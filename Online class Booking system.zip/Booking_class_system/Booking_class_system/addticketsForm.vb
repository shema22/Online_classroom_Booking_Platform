﻿Imports MySql.Data.MySqlClient

Public Class addticketsForm
    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Dim connectionString = "server=localhost;user id=root;password=;database=ur_huye_system"
        Using conn As New MySqlConnection(connectionString)
            conn.Open()



            Dim query As String = "SELECT COUNT(notification_id) FROM notifications INNER JOIN users ON notifications.user_id = users.user_id WHERE users.role = 'admin'"
            Dim cmd As New MySqlCommand(Query, conn)
            Button6.Text = "Total Admin's Post: " & cmd.ExecuteScalar.ToString

        End Using
    End Sub


    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        Dim connectionString As String = "server=localhost;user id=root;password=;database=ur_huye_system"
        Using conn As New MySqlConnection(connectionString)
            Try
                conn.Open()
                Dim query As String = "INSERT INTO notifications (user_id, message) VALUES (@user_id, @message)"
                Using cmd As New MySqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@user_id", Convert.ToInt32(user_id.Text))
                    cmd.Parameters.AddWithValue("@message", message.Text)
                    cmd.ExecuteNonQuery()
                    MessageBox.Show("Notification added successfully!")
                    RetrieveData() ' Refresh the DataGridView to display the new data
                End Using
            Catch ex As MySqlException
                MessageBox.Show("Database error: " & ex.Message)
            Catch ex As Exception
                MessageBox.Show("An error occurred: " & ex.Message)
            End Try
        End Using
    End Sub
    Private Sub RetrieveData()
        Dim connectionString As String = "server=localhost;user id=root;password=;database=ur_huye_system"
        Using conn As New MySqlConnection(connectionString)
            Try
                conn.Open()
                Dim query As String = "SELECT notification_id, user_id, message FROM notifications"
                Using cmd As New MySqlCommand(query, conn)
                    Dim adapter As New MySqlDataAdapter(cmd)
                    Dim table As New DataTable()
                    adapter.Fill(table)
                    dgvNotifications.DataSource = table

                    ' Configure column headers
                    If dgvNotifications.Columns.Contains("notification_id") Then
                        dgvNotifications.Columns("notification_id").HeaderText = "Notification ID"
                    End If
                    If dgvNotifications.Columns.Contains("user_id") Then
                        dgvNotifications.Columns("user_id").HeaderText = "User ID"
                    End If
                    If dgvNotifications.Columns.Contains("message") Then
                        dgvNotifications.Columns("message").HeaderText = "Message"
                    End If
                End Using
            Catch ex As MySqlException
                MessageBox.Show("Database error: " & ex.Message)
            Catch ex As Exception
                MessageBox.Show("An error occurred: " & ex.Message)
            End Try
        End Using
    End Sub

    ' Call RetrieveData when the form loads to display existing notifications
    Private Sub UserManagementForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        RetrieveData()
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        user_id.Text = ""
        message.Text = ""

    End Sub
    Private Sub dgvNotifications_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvNotifications.CellContentClick
        ' Ensure the user clicks on a valid cell
        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow = dgvNotifications.Rows(e.RowIndex)
            user_id.Text = row.Cells("user_id").Value.ToString()
            message.Text = row.Cells("message").Value.ToString()
        End If
    End Sub


    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If dgvNotifications.SelectedRows.Count > 0 Then
            Dim selectedRow As DataGridViewRow = dgvNotifications.SelectedRows(0)
            Dim notificationId As Integer = Convert.ToInt32(selectedRow.Cells("notification_id").Value)

            Dim connectionString As String = "server=localhost;user id=root;password=;database=ur_huye_system"
            Using conn As New MySqlConnection(connectionString)
                Try
                    conn.Open()
                    Dim query As String = "UPDATE notifications SET user_id = @user_id, message = @message WHERE notification_id = @notification_id"
                    Using cmd As New MySqlCommand(query, conn)
                        cmd.Parameters.AddWithValue("@notification_id", notificationId)
                        cmd.Parameters.AddWithValue("@user_id", Convert.ToInt32(user_id.Text))
                        cmd.Parameters.AddWithValue("@message", message.Text)
                        Dim rowsAffected As Integer = cmd.ExecuteNonQuery()
                        If rowsAffected > 0 Then
                            MessageBox.Show("Notification updated successfully!")
                            RetrieveData() ' Refresh the DataGridView to display updated data
                        Else
                            MessageBox.Show("No update made. Please select a notification to update.")
                        End If
                    End Using
                Catch ex As MySqlException
                    MessageBox.Show("Database error: " & ex.Message)
                Catch ex As Exception
                    MessageBox.Show("An error occurred: " & ex.Message)
                End Try
            End Using
        Else
            MessageBox.Show("Please select a notification to update.")
        End If
    End Sub



    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If dgvNotifications.SelectedRows.Count > 0 Then
            Dim selectedRow As DataGridViewRow = dgvNotifications.SelectedRows(0)
            Dim notificationId As Integer = Convert.ToInt32(selectedRow.Cells("notification_id").Value)

            Dim connectionString As String = "server=localhost;user id=root;password=;database=ur_huye_system"
            Using conn As New MySqlConnection(connectionString)
                Try
                    conn.Open()
                    Dim query As String = "DELETE FROM notifications WHERE notification_id = @notification_id"
                    Using cmd As New MySqlCommand(query, conn)
                        cmd.Parameters.AddWithValue("@notification_id", notificationId)
                        Dim rowsAffected As Integer = cmd.ExecuteNonQuery()
                        If rowsAffected > 0 Then
                            MessageBox.Show("Notification deleted successfully!")
                            RetrieveData() ' Refresh the DataGridView to remove deleted data
                        Else
                            MessageBox.Show("No deletion made. Please select a notification to delete.")
                        End If
                    End Using
                Catch ex As MySqlException
                    MessageBox.Show("Database error: " & ex.Message)
                Catch ex As Exception
                    MessageBox.Show("An error occurred: " & ex.Message)
                End Try
            End Using
        Else
            MessageBox.Show("Please select a notification to delete.")
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim das As New mainForm()
        mainForm.Show()
        Me.Hide()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim user As New addUser()
        user.Show()
        Me.Hide()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim clas As New addclassForm()
        clas.Show()
        Me.Hide()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim ticket As New addticketsForm()
        Me.Show()
        Me.Hide()

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim st As New bookingstatus()
        bookingstatus.Show()
        Me.Hide()
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        Dim check = DialogResult = MessageBox.Show("Are you want to logout?", "Confirmation message", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If check = DialogResult.Yes Then
            Dim log As New LoginForm()
            LoginForm.Show()

            Me.Hide()

        End If
    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click
        Application.Exit()
    End Sub

    Private Sub cp_Click(sender As Object, e As EventArgs) Handles cp.Click
        Dim connectionString = "server=localhost;user id=root;password=;database=ur_huye_system"
        Using conn As New MySqlConnection(connectionString)
            conn.Open()



            Dim query As String = "SELECT COUNT(notification_id) FROM notifications INNER JOIN users ON notifications.user_id = users.user_id WHERE users.role = 'user'"
            Dim cmd As New MySqlCommand(query, conn)
            cp.Text = "Total CP's Post: " & cmd.ExecuteScalar.ToString

        End Using
    End Sub
End Class