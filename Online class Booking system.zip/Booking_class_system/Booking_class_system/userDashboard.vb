﻿Imports System.Diagnostics.Eventing
Imports MySql.Data.MySqlClient
Imports Mysqlx.XDevAPI.Relational
Imports Windows.Win32.System

Public Class userDashboard
    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        LoadBookingData()
    End Sub
    Private Sub LoadBookingData()
        Dim connectionString As String = "server=localhost;user id=root;password=;database=ur_huye_system"
        Using conn As New MySqlConnection(connectionString)
            Try
                conn.Open()

                ' Create the SQL query with INNER JOINs
                Dim query As String = "SELECT b.booking_id, c.name AS classroom_name, " &
                                    "c.size, c.location, u.names AS user_name, " &
                                    "b.date_booked " &
                                    "FROM bookings b " &
                                    "INNER JOIN classrooms c ON b.classroom_id = c.classroom_id " &
                                    "INNER JOIN users u ON b.user_id = u.user_id"

                ' Create adapter and dataset
                Dim adapter As New MySqlDataAdapter(query, conn)
                Dim dataset As New DataSet()

                ' Fill the dataset
                adapter.Fill(dataset, "BookingDetails")

                ' Bind the data to DataGridView
                DataGridView1.DataSource = dataset.Tables("BookingDetails")

                ' Optionally format the column headers for better readability
                DataGridView1.Columns("classroom_name").HeaderText = "Classroom Name"
                DataGridView1.Columns("size").HeaderText = "Size"
                DataGridView1.Columns("location").HeaderText = "Location"
                DataGridView1.Columns("user_name").HeaderText = "Booked By"
                DataGridView1.Columns("date_booked").HeaderText = "Booking Date"

                ' AutoSize the columns for better appearance
                DataGridView1.AutoResizeColumns()

            Catch ex As MySqlException
                MessageBox.Show("Error loading data: " & ex.Message)
            End Try
        End Using
    End Sub
    Private Sub YourForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadBookingData()
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Dim connectionString = "server=localhost;user id=root;password=;database=ur_huye_system"
        Using conn As New MySqlConnection(connectionString)
            Try
                conn.Open()
                ' Load Total Available Classrooms
                Dim Query = "SELECT COUNT(*) FROM classrooms WHERE status = 'free'"
                Dim cmd As New MySqlCommand(Query, conn)
                Button7.Text = "Available Rooms: " & cmd.ExecuteScalar().ToString()
            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message)
            End Try
        End Using
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Dim connectionString = "server=localhost;user id=root;password=;database=ur_huye_system"
        Using conn As New MySqlConnection(connectionString)
            Try
                conn.Open()
                ' Load Total Available Classrooms
                Dim Query = "SELECT COUNT(*) FROM bookings"
                Dim cmd As New MySqlCommand(Query, conn)
                Button6.Text = "Booked Rooms: " & cmd.ExecuteScalar().ToString()
            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message)
            End Try
        End Using
    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click
        Application.Exit()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim booking As New addBooking()
        addBooking.Show()
        Me.Hide()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim check = DialogResult = MessageBox.Show("Are you want to logout?", "Confirmation message", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If check = DialogResult.Yes Then
            LoginForm.Show()

            Me.Hide()

        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim tic As New ticketsForm()
        ticketsForm.Show()
        Me.Hide()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        MessageBox.Show("This is property of UR! the system is under deploy so keep wait until mentained or contact IT Department.thank you!")
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim d As New userDashboard()
        Me.Show()
    End Sub
End Class