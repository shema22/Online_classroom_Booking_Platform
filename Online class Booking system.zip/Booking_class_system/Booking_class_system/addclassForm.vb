﻿Imports MySql.Data.MySqlClient
Imports Mysqlx.Connection
Imports Mysqlx.XDevAPI
Imports NPOI.Util


Public Class addclassForm
    Private Sub class_addbtn_Click(sender As Object, e As EventArgs) Handles class_addbtn.Click
        Dim connectionString As String = "server=localhost;user id=root;password=;database=ur_huye_system"
        Using conn As New MySqlConnection(connectionString)
            Try
                conn.Open()

                Dim query As String = "INSERT INTO classrooms (name, size, status, location, details) VALUES (@class_name, @class_size, @class_status, @class_location, @class_details)"
                Using cmd As New MySqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@class_name", class_name.Text)
                    cmd.Parameters.AddWithValue("@class_size", class_size.Text)
                    cmd.Parameters.AddWithValue("@class_status", class_status.Text)
                    cmd.Parameters.AddWithValue("@class_location", class_location.Text)
                    cmd.Parameters.AddWithValue("@class_details", class_details.Text)
                    cmd.ExecuteNonQuery()
                    MessageBox.Show("Classroom added successfully!")
                    ' Set a timer to update the status back to 'free' after 12 hours



                    RetrieveData()
                End Using
            Catch ex As MySqlException
                MessageBox.Show(ex.Message)

            End Try
        End Using
    End Sub

    Private Sub TimerElapsed(sender As Object, e As Timers.ElapsedEventArgs, classroomId As Integer)
        ' Stop and dispose of the timer
        CType(sender, Timers.Timer).Stop()
        CType(sender, Timers.Timer).Dispose()
        Dim timer As New Timers.Timer
        timer.Interval = 12 * 60 * 60 * 1000

        ' Update classroom status
        UpdateClassroomStatus(classroomId)
    End Sub
    Private Sub UpdateClassroomStatus(classroomId As Integer)
        Dim connectionString As String = "server=localhost;user id=root;password=;database=ur_huye_system"
        Using conn As New MySqlConnection(connectionString)
            Try
                conn.Open()
                Dim query As String = "UPDATE classrooms SET status = 'free' WHERE classroom_id = @classroom_id"
                Using cmd As New MySqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@classroom_id", classroomId)
                    cmd.ExecuteNonQuery()
                End Using
                MessageBox.Show("Classroom status updated to 'free'")
            Catch ex As MySqlException
                MessageBox.Show("Database error: " & ex.Message)
            Catch ex As Exception
                MessageBox.Show("An error occurred: " & ex.Message)
            End Try
        End Using
    End Sub
    Private Sub class_clearbtn_Click(sender As Object, e As EventArgs) Handles class_clearbtn.Click
        class_name.Text = ""
        class_size.Text = ""
        class_status.Text = ""
        class_location.Text = ""
        class_details.Text = ""


    End Sub


    Private Sub class_DataGridView_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles class_DataGridView.CellClick
        ' Ensure the user clicks on a valid cell
        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow = class_DataGridView.Rows(e.RowIndex)
            class_name.Text = row.Cells("name").Value.ToString()
            class_size.Text = row.Cells("size").Value.ToString()
            class_status.Text = row.Cells("status").Value.ToString()
            class_location.Text = row.Cells("location").Value.ToString()
            class_details.Text = row.Cells("details").Value.ToString()

        End If
    End Sub







    Private Sub RetrieveData()
        Dim connectionString As String = "server=localhost;user id=root;password=;database=ur_huye_system"
        Using conn As New MySqlConnection(connectionString)
            Try
                conn.Open()
                Dim query As String = "SELECT classroom_id, name, size, status, location, details FROM classrooms"
                Using cmd As New MySqlCommand(query, conn)
                    Dim adapter As New MySqlDataAdapter(cmd)
                    Dim table As New DataTable()
                    adapter.Fill(table)
                    class_DataGridView.DataSource = table


                    If class_DataGridView.Columns.Contains("classroom_id") Then
                        class_DataGridView.Columns("classroom_id").HeaderText = "Class ID"
                    End If
                    If class_DataGridView.Columns.Contains("name") Then
                        class_DataGridView.Columns("name").HeaderText = "Class Name"
                    End If
                    If class_DataGridView.Columns.Contains("size") Then
                        class_DataGridView.Columns("size").HeaderText = "Class Size"
                    End If
                    If class_DataGridView.Columns.Contains("status") Then
                        class_DataGridView.Columns("status").HeaderText = "Status"
                    End If
                    If class_DataGridView.Columns.Contains("location") Then
                        class_DataGridView.Columns("location").HeaderText = "Location"
                    End If
                    If class_DataGridView.Columns.Contains("details") Then
                        class_DataGridView.Columns("details").HeaderText = "Details"
                    End If
                End Using
            Catch ex As MySqlException
                MessageBox.Show("Database error: " & ex.Message)
            Catch ex As Exception
                MessageBox.Show("An error occurred: " & ex.Message)
            End Try
        End Using
    End Sub

    Private Sub UserManagementForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        RetrieveData()
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If class_DataGridView.SelectedRows.Count > 0 Then
            ' Correctly retrieve the selected row
            Dim selectedRow As DataGridViewRow = class_DataGridView.SelectedRows(0)
            Dim classId As Integer = Convert.ToInt32(selectedRow.Cells("classroom_id").Value)

            Dim connectionString As String = "server=localhost;user id=root;password=;database=ur_huye_system"
            Using conn As New MySqlConnection(connectionString)
                Try
                    conn.Open()
                    Dim query As String = "UPDATE classrooms SET name = @name, size = @size, status = @status, location = @location, details = @details WHERE classroom_id = @class_id"
                    Using cmd As New MySqlCommand(query, conn)
                        cmd.Parameters.AddWithValue("@class_id", classId)
                        cmd.Parameters.AddWithValue("@name", class_name.Text)
                        cmd.Parameters.AddWithValue("@size", Convert.ToInt32(class_size.Text)) ' Ensuring size is converted to integer
                        cmd.Parameters.AddWithValue("@status", class_status.Text)
                        cmd.Parameters.AddWithValue("@location", class_location.Text)
                        cmd.Parameters.AddWithValue("@details", class_details.Text)

                        Dim rowsAffected As Integer = cmd.ExecuteNonQuery()
                        If rowsAffected > 0 Then
                            MessageBox.Show("Classroom updated successfully!")

                            RetrieveData() ' Refresh the DataGridView to display updated data
                        Else
                            MessageBox.Show("No update made. Please select a classroom to update.")
                        End If
                    End Using
                Catch ex As MySqlException
                    MessageBox.Show("Database error: " & ex.Message)
                Catch ex As Exception
                    MessageBox.Show("An error occurred: " & ex.Message)
                End Try
            End Using
        Else
            MessageBox.Show("Please select a classroom to update.")
        End If
    End Sub


    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If class_DataGridView.SelectedRows.Count > 0 Then
            Dim selectedRow As DataGridViewRow = class_DataGridView.SelectedRows(0)
            Dim classId As Integer = Convert.ToInt32(selectedRow.Cells("classroom_id").Value)

            Dim connectionString As String = "server=localhost;user id=root;password=;database=ur_huye_system"
            Using conn As New MySqlConnection(connectionString)
                Try
                    conn.Open()
                    Dim query As String = "DELETE FROM classrooms WHERE classroom_id = @class_id"
                    Using cmd As New MySqlCommand(query, conn)
                        cmd.Parameters.AddWithValue("@class_id", classId)
                        Dim rowsAffected As Integer = cmd.ExecuteNonQuery()
                        If rowsAffected > 0 Then
                            MessageBox.Show("classroom deleted successfully!")
                            RetrieveData() ' Refresh the DataGridView to remove deleted data
                        Else
                            MessageBox.Show("No deletion made. Please select a classroom to delete.")
                        End If
                    End Using
                Catch ex As MySqlException
                    MessageBox.Show("Database error: " & ex.Message)
                Catch ex As Exception
                    MessageBox.Show("An error occurred: " & ex.Message)
                End Try
            End Using
        Else
            MessageBox.Show("Please select a classroom to delete.")
        End If
    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click
        Application.Exit()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim dash As New mainForm()
        dash.Show()
        Me.Hide()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim user As New addUser()
        user.Show()
        Me.Hide()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim clas As New addclassForm()
        clas.Show()
        Me.Hide()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim tic As New addticketsForm()
        tic.Show()
        Me.Hide()
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        Dim check = DialogResult = MessageBox.Show("Are you want to logout?", "Confirmation message", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If check = DialogResult.Yes Then
            Dim log As New LoginForm()
            LoginForm.Show()

            Me.Hide()

        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim st As New bookingstatus()
        bookingstatus.Show()
        Me.Hide()
    End Sub
End Class