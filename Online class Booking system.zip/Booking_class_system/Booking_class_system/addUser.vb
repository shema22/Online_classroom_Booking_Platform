﻿Imports System.Data.SqlClient
Imports K4os.Compression.LZ4.Streams
Imports MySql.Data.MySqlClient


Public Class addUser
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim connectionString As String = "server=localhost;user id=root;password=;database=ur_huye_system"
        Using conn As New MySqlConnection(connectionString)
            Try
                conn.Open()
                Dim query As String = "INSERT INTO users (names, username,email, password, role) VALUES (@name, @username, @email, @pass, @role)"
                Using cmd As New MySqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@name", txtFullName.Text)
                    cmd.Parameters.AddWithValue("@username", txtUsername.Text)
                    cmd.Parameters.AddWithValue("@email", txtEmail.Text)
                    cmd.Parameters.AddWithValue("@pass", txtPassword.Text)
                    cmd.Parameters.AddWithValue("@role", cboRole.Text)
                    cmd.ExecuteNonQuery()
                    MessageBox.Show("user added successfully!")
                    RetrieveData()
                End Using
            Catch ex As MySqlException
                MessageBox.Show(ex.Message)

            End Try
        End Using
    End Sub





    Private Sub RetrieveData()
        Dim connectionString As String = "server=localhost;user id=root;password=;database=ur_huye_system"
        Using conn As New MySqlConnection(connectionString)
            Try
                conn.Open()
                Console.WriteLine("Connection opened")
                Dim query As String = "SELECT 
                                    user_id,
                                    names,
                                    username,
                                    email,
                                    password,
                                    role
                                  FROM Users"
                Console.WriteLine("Executing query: " & query)
                Using cmd As New MySqlCommand(query, conn)
                    Dim adapter As New MySqlDataAdapter(cmd)
                    Dim table As New DataTable()
                    adapter.Fill(table)
                    Console.WriteLine("Rows retrieved: " & table.Rows.Count)
                    dgvUsers.DataSource = table

                    ' Configure column headers
                    If dgvUsers.Columns.Contains("user_id") Then
                        dgvUsers.Columns("user_id").HeaderText = "ID"
                    End If
                    If dgvUsers.Columns.Contains("names") Then
                        dgvUsers.Columns("names").HeaderText = "Full Name"
                    End If
                    If dgvUsers.Columns.Contains("username") Then
                        dgvUsers.Columns("username").HeaderText = "Username"
                    End If
                    If dgvUsers.Columns.Contains("email") Then
                        dgvUsers.Columns("email").HeaderText = "Email"
                    End If

                    ' Optionally hide sensitive columns
                    If dgvUsers.Columns.Contains("password") Then
                        dgvUsers.Columns("password").Visible = False
                    End If
                    If dgvUsers.Columns.Contains("role") Then
                        dgvUsers.Columns("role").HeaderText = "Role"
                    End If
                End Using
            Catch ex As MySqlException
                MessageBox.Show("Database error: " & ex.Message)
            Catch ex As Exception
                MessageBox.Show("An error occurred: " & ex.Message)
            End Try
        End Using
    End Sub
    Private Sub UserManagementForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        RetrieveData()
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        Dim check = DialogResult = MessageBox.Show("Are you want to logout?", "Confirmation message", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If check = DialogResult.Yes Then
            Dim log As New LoginForm()
            LoginForm.Show()

            Me.Hide()

        End If
    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click
        Application.Exit()


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim dash As New mainForm()
        mainForm.Show()
        Me.Hide()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim user As New addUser()
        Me.Show()
        Me.Hide()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim clas As New addclassForm()
        addclassForm.Show()
        Me.Hide()

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim tk As New addticketsForm()
        addticketsForm.Show()
        Me.Hide()
    End Sub


    Private Sub dgvUsers_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvUsers.CellContentClick
        ' Ensure the user clicks on a valid cell
        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow = dgvUsers.Rows(e.RowIndex)
            txtFullName.Text = row.Cells("names").Value.ToString()
            txtUsername.Text = row.Cells("username").Value.ToString()
            txtEmail.Text = row.Cells("email").Value.ToString()
            txtPassword.Text = row.Cells("password").Value.ToString()
            cboRole.Text = row.Cells("role").Value.ToString()
        End If
    End Sub


    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If dgvUsers.SelectedRows.Count > 0 Then
            Dim selectedRow As DataGridViewRow = dgvUsers.SelectedRows(0)
            Dim Id As Integer = Convert.ToInt32(selectedRow.Cells("user_id").Value)

            Dim connectionString As String = "server=localhost;user id=root;password=;database=ur_huye_system"
            Using conn As New MySqlConnection(connectionString)
                Try
                    conn.Open()
                    Dim query As String = "UPDATE users SET names = @user, username = @username,email=@email,password=@pass,role=@role WHERE user_id = @user_id"
                    Using cmd As New MySqlCommand(query, conn)
                        cmd.Parameters.AddWithValue("@user_id", Id)
                        cmd.Parameters.AddWithValue("@user", txtFullName.Text)
                        cmd.Parameters.AddWithValue("@username", txtUsername.Text)
                        cmd.Parameters.AddWithValue("@email", txtEmail.Text)
                        cmd.Parameters.AddWithValue("@pass", txtPassword.Text)
                        cmd.Parameters.AddWithValue("@role", cboRole.Text)
                        Dim rowsAffected As Integer = cmd.ExecuteNonQuery()
                        If rowsAffected > 0 Then
                            MessageBox.Show("user updated successfully!")
                            RetrieveData() ' Refresh the DataGridView to display updated data
                        Else
                            MessageBox.Show("No update made. Please select a notification to update.")
                        End If
                    End Using
                Catch ex As MySqlException
                    MessageBox.Show("Database error: " & ex.Message)
                Catch ex As Exception
                    MessageBox.Show("An error occurred: " & ex.Message)
                End Try
            End Using
        Else
            MessageBox.Show("Please select a user to update.")
        End If
    End Sub



    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If dgvUsers.SelectedRows.Count > 0 Then
            Dim selectedRow As DataGridViewRow = dgvUsers.SelectedRows(0)
            Dim Id As Integer = Convert.ToInt32(selectedRow.Cells("user_id").Value)

            Dim connectionString As String = "server=localhost;user id=root;password=;database=ur_huye_system"
            Using conn As New MySqlConnection(connectionString)
                Try
                    conn.Open()
                    Dim query As String = "DELETE FROM users WHERE user_id = @user_id"
                    Using cmd As New MySqlCommand(query, conn)
                        cmd.Parameters.AddWithValue("@user_id", Id)
                        Dim rowsAffected As Integer = cmd.ExecuteNonQuery()
                        If rowsAffected > 0 Then
                            MessageBox.Show("user deleted successfully!")
                            RetrieveData() ' Refresh the DataGridView to remove deleted data
                        Else
                            MessageBox.Show("No deletion made. Please select a user to delete.")
                        End If
                    End Using
                Catch ex As MySqlException
                    MessageBox.Show("Database error: " & ex.Message)
                Catch ex As Exception
                    MessageBox.Show("An error occurred: " & ex.Message)
                End Try
            End Using
        Else
            MessageBox.Show("Please select a user to delete.")
        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtFullName.Text = ""
        txtUsername.Text = ""
        txtEmail.Text = ""
        txtPassword.Text = ""
        cboRole.Text = ""
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim st As New bookingstatus()
        bookingstatus.Show()
        Me.Hide()
    End Sub
End Class