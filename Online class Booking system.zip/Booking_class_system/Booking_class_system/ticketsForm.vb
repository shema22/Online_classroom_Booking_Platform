﻿Imports MySql.Data.MySqlClient

Public Class ticketsForm
    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        Dim connectionString As String = "server=localhost;user id=root;password=;database=ur_huye_system"
        Using conn As New MySqlConnection(connectionString)
            Try
                conn.Open()
                Dim query As String = "INSERT INTO notifications (user_id, message) VALUES (@user_id, @message)"
                Using cmd As New MySqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@user_id", Convert.ToInt32(user_id.Text))
                    cmd.Parameters.AddWithValue("@message", message.Text)
                    cmd.ExecuteNonQuery()
                    MessageBox.Show("Ticket raised successfully!")
                    RetrieveData() ' Refresh the DataGridView to display the new data
                End Using
            Catch ex As MySqlException
                MessageBox.Show("Database error: " & ex.Message)
            Catch ex As Exception
                MessageBox.Show("An error occurred: " & ex.Message)
            End Try
        End Using
    End Sub
    Private Sub RetrieveData()
        Dim connectionString As String = "server=localhost;user id=root;password=;database=ur_huye_system"
        Using conn As New MySqlConnection(connectionString)
            Try
                conn.Open()
                Dim query As String = "SELECT notification_id, user_id, message FROM notifications"
                Using cmd As New MySqlCommand(query, conn)
                    Dim adapter As New MySqlDataAdapter(cmd)
                    Dim table As New DataTable()
                    adapter.Fill(table)
                    DataGridView1.DataSource = table

                    ' Configure column headers
                    If DataGridView1.Columns.Contains("notification_id") Then
                        DataGridView1.Columns("notification_id").HeaderText = "Notification ID"
                    End If
                    If DataGridView1.Columns.Contains("user_id") Then
                        DataGridView1.Columns("user_id").HeaderText = "User ID"
                    End If
                    If DataGridView1.Columns.Contains("message") Then
                        DataGridView1.Columns("message").HeaderText = "Message"
                    End If
                End Using
            Catch ex As MySqlException
                MessageBox.Show("Database error: " & ex.Message)
            Catch ex As Exception
                MessageBox.Show("An error occurred: " & ex.Message)
            End Try
        End Using
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        user_id.Text = ""
        message.Text = ""
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Dim connectionString = "server=localhost;user id=root;password=;database=ur_huye_system"
        Using conn As New MySqlConnection(connectionString)
            conn.Open()



            Dim query As String = "SELECT COUNT(notification_id) FROM notifications INNER JOIN users ON notifications.user_id = users.user_id WHERE users.role = 'admin'"
            Dim cmd As New MySqlCommand(query, conn)
            Button6.Text = "Total Admin's Post: " & cmd.ExecuteScalar.ToString

        End Using
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Dim connectionString = "server=localhost;user id=root;password=;database=ur_huye_system"
        Using conn As New MySqlConnection(connectionString)
            conn.Open()



            Dim query As String = "SELECT COUNT(notification_id) FROM notifications INNER JOIN users ON notifications.user_id = users.user_id WHERE users.role = 'user'"
            Dim cmd As New MySqlCommand(query, conn)
            Button7.Text = "Total CP's Post: " & cmd.ExecuteScalar.ToString

        End Using
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim dash As New userDashboard()
        userDashboard.Show()
        Me.Hide()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim b As New addBooking()
        addBooking.Show()
        Me.Hide()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim r As New ticketsForm()
        Me.Show()

    End Sub
    Private Sub UserManagementForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        RetrieveData()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        MessageBox.Show("This is property of UR! the system is under deploy so keep wait until mentained or contact IT Department.thank you!")
    End Sub
End Class